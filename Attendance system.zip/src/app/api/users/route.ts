import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { desc, eq, or } from "drizzle-orm";
import { generateDeterministicEmbedding } from "@/lib/face-recognition";

export async function GET(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const searchParams = req.nextUrl.searchParams;
    const query = searchParams.get("q") || "";
    const department = searchParams.get("department");

    const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));

    let filtered = allUsers;

    if (query) {
      const q = query.toLowerCase();
      filtered = filtered.filter(
        (u) =>
          u.name.toLowerCase().includes(q) ||
          u.employeeId.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.role.toLowerCase().includes(q)
      );
    }

    if (department && department !== "all") {
      filtered = filtered.filter((u) => u.department === department);
    }

    return NextResponse.json({
      success: true,
      users: filtered,
      total: filtered.length,
    });
  } catch (error: unknown) {
    console.error("GET /api/users error:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to fetch users" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await req.json();
    const {
      name,
      email,
      employeeId,
      role = "Staff",
      department = "Engineering",
      shiftStart = "09:00",
      shiftEnd = "18:00",
      photoUrl,
      faceEmbedding,
      phone,
      pinCode,
    } = body;

    if (!name || !email || !employeeId) {
      return NextResponse.json(
        { success: false, error: "Name, Employee ID, and Email are required fields." },
        { status: 400 }
      );
    }

    // Check duplicate employee ID or email
    const existing = await db
      .select()
      .from(users)
      .where(or(eq(users.employeeId, employeeId), eq(users.email, email)));

    if (existing.length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: existing[0].employeeId === employeeId
            ? `Employee ID "${employeeId}" is already registered.`
            : `Email "${email}" is already registered.`,
        },
        { status: 409 }
      );
    }

    // Ensure we have a valid 128-d face embedding
    let finalEmbedding = faceEmbedding;
    if (!finalEmbedding || !Array.isArray(finalEmbedding) || finalEmbedding.length === 0) {
      finalEmbedding = generateDeterministicEmbedding(employeeId + name + (photoUrl || ""));
    }

    const [newUser] = await db
      .insert(users)
      .values({
        name,
        email,
        employeeId,
        role,
        department,
        shiftStart,
        shiftEnd,
        photoUrl: photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`,
        faceEmbedding: finalEmbedding,
        phone,
        pinCode: pinCode || employeeId.replace(/\D/g, "").slice(-4) || "1234",
        isActive: true,
      })
      .returning();

    return NextResponse.json({
      success: true,
      user: newUser,
      message: `Employee ${name} (${employeeId}) successfully enrolled!`,
    }, { status: 201 });
  } catch (error: unknown) {
    console.error("POST /api/users error:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to register employee" },
      { status: 500 }
    );
  }
}
