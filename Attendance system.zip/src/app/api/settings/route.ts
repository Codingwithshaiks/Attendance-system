import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { systemSettings } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const settings = await db.select().from(systemSettings).limit(1);
    return NextResponse.json({
      success: true,
      settings: settings[0] || null,
    });
  } catch (error: unknown) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to fetch settings" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await req.json();
    const {
      organizationName,
      confidenceThreshold,
      livenessCheckEnabled,
      workStartTime,
      gracePeriodMinutes,
      autoCaptureIntervalMs,
      kioskModePasscode,
      soundEffectsEnabled,
    } = body;

    const current = await db.select().from(systemSettings).limit(1);
    if (current.length === 0) {
      const [newSettings] = await db
        .insert(systemSettings)
        .values({
          organizationName: organizationName || "Apex HQ",
          confidenceThreshold: confidenceThreshold ?? 0.72,
          livenessCheckEnabled: livenessCheckEnabled ?? true,
          workStartTime: workStartTime || "09:00",
          gracePeriodMinutes: gracePeriodMinutes ?? 15,
          autoCaptureIntervalMs: autoCaptureIntervalMs ?? 2500,
          kioskModePasscode: kioskModePasscode || "1234",
          soundEffectsEnabled: soundEffectsEnabled ?? true,
        })
        .returning();
      return NextResponse.json({ success: true, settings: newSettings });
    }

    const [updated] = await db
      .update(systemSettings)
      .set({
        organizationName: organizationName !== undefined ? organizationName : current[0].organizationName,
        confidenceThreshold:
          confidenceThreshold !== undefined ? confidenceThreshold : current[0].confidenceThreshold,
        livenessCheckEnabled:
          livenessCheckEnabled !== undefined ? livenessCheckEnabled : current[0].livenessCheckEnabled,
        workStartTime: workStartTime !== undefined ? workStartTime : current[0].workStartTime,
        gracePeriodMinutes:
          gracePeriodMinutes !== undefined ? gracePeriodMinutes : current[0].gracePeriodMinutes,
        autoCaptureIntervalMs:
          autoCaptureIntervalMs !== undefined ? autoCaptureIntervalMs : current[0].autoCaptureIntervalMs,
        kioskModePasscode:
          kioskModePasscode !== undefined ? kioskModePasscode : current[0].kioskModePasscode,
        soundEffectsEnabled:
          soundEffectsEnabled !== undefined ? soundEffectsEnabled : current[0].soundEffectsEnabled,
        updatedAt: new Date(),
      })
      .where(eq(systemSettings.id, current[0].id))
      .returning();

    return NextResponse.json({ success: true, settings: updated });
  } catch (error: unknown) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to update settings" },
      { status: 500 }
    );
  }
}
