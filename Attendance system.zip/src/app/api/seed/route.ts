import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, attendanceLogs, departments, systemSettings } from "@/db/schema";
import { SAMPLE_EMPLOYEES } from "@/db/seed";
import { generateDeterministicEmbedding } from "@/lib/face-recognition";

export async function POST() {
  try {
    // Clear existing
    await db.delete(attendanceLogs);
    await db.delete(users);
    await db.delete(departments);
    await db.delete(systemSettings);

    // Departments
    const depts = [
      { name: "Engineering", code: "ENG", description: "Software, AI, and Infrastructure" },
      { name: "Product & Design", code: "PRD", description: "Product Management and UX/UI Design" },
      { name: "Human Resources", code: "HR", description: "Talent Acquisition and Employee Relations" },
      { name: "Operations", code: "OPS", description: "Global Facilities and IT Infrastructure" },
      { name: "Marketing", code: "MKT", description: "Growth, Brand, and Communications" },
      { name: "Sales", code: "SLS", description: "Enterprise and Account Management" },
    ];
    for (const d of depts) {
      await db.insert(departments).values(d);
    }

    // System Settings
    await db.insert(systemSettings).values({
      organizationName: "Apex Cybernetics HQ",
      confidenceThreshold: 0.72,
      livenessCheckEnabled: true,
      workStartTime: "09:00",
      gracePeriodMinutes: 15,
      autoCaptureIntervalMs: 2500,
      kioskModePasscode: "1234",
      soundEffectsEnabled: true,
    });

    const createdUsers = [];
    for (const emp of SAMPLE_EMPLOYEES) {
      const embedding = generateDeterministicEmbedding(emp.employeeId + emp.name);
      const [u] = await db
        .insert(users)
        .values({
          ...emp,
          faceEmbedding: embedding,
        })
        .returning();
      createdUsers.push(u);
    }

    // Today's attendance logs
    const today = new Date();

    const t1 = new Date(today);
    t1.setHours(8, 46, 12, 0);
    await db.insert(attendanceLogs).values({
      userId: createdUsers[0].id,
      timestamp: t1,
      type: "check_in",
      status: "on_time",
      confidenceScore: 0.984,
      verificationMethod: "facial_live",
      snapshotUrl: createdUsers[0].photoUrl,
      deviceInfo: "Main Terminal Kiosk #1 (Chrome 128 / macOS)",
      locationTag: "Apex HQ - Lobby Portal A",
      notes: "Biometric face verification matched (98.4%)",
    });

    const t2 = new Date(today);
    t2.setHours(8, 58, 30, 0);
    await db.insert(attendanceLogs).values({
      userId: createdUsers[1].id,
      timestamp: t2,
      type: "check_in",
      status: "on_time",
      confidenceScore: 0.967,
      verificationMethod: "facial_live",
      snapshotUrl: createdUsers[1].photoUrl,
      deviceInfo: "Mobile Web Scanner (iOS Safari)",
      locationTag: "Apex HQ - South Entrance",
      notes: "Liveness verification passed: 0.97",
    });

    const t3 = new Date(today);
    t3.setHours(9, 28, 15, 0);
    await db.insert(attendanceLogs).values({
      userId: createdUsers[2].id,
      timestamp: t3,
      type: "check_in",
      status: "late",
      confidenceScore: 0.952,
      verificationMethod: "facial_live",
      snapshotUrl: createdUsers[2].photoUrl,
      deviceInfo: "Main Terminal Kiosk #2 (Linux Touch)",
      locationTag: "Apex HQ - Lobby Portal B",
      notes: "Late arrival (+28 mins)",
    });

    const t4 = new Date(today);
    t4.setHours(8, 25, 40, 0);
    await db.insert(attendanceLogs).values({
      userId: createdUsers[3].id,
      timestamp: t4,
      type: "check_in",
      status: "on_time",
      confidenceScore: 0.991,
      verificationMethod: "facial_live",
      snapshotUrl: createdUsers[3].photoUrl,
      deviceInfo: "HR Floor Tablet Scanner",
      locationTag: "Apex HQ - 4th Floor HR",
      notes: "Biometric scan verified (99.1%)",
    });

    const t5 = new Date(today);
    t5.setHours(9, 10, 5, 0);
    await db.insert(attendanceLogs).values({
      userId: createdUsers[4].id,
      timestamp: t5,
      type: "check_in",
      status: "on_time",
      confidenceScore: 0.978,
      verificationMethod: "facial_live",
      snapshotUrl: createdUsers[4].photoUrl,
      deviceInfo: "Main Terminal Kiosk #1",
      locationTag: "Apex HQ - Lobby Portal A",
      notes: "Automated biometric match verified",
    });

    // 5 days history
    for (let dayOffset = 1; dayOffset <= 5; dayOffset++) {
      const pastDate = new Date(today);
      pastDate.setDate(today.getDate() - dayOffset);

      for (let i = 0; i < 6; i++) {
        const user = createdUsers[i];
        const checkInTime = new Date(pastDate);
        const isLate = Math.random() < 0.2;
        checkInTime.setHours(isLate ? 9 : 8, Math.floor(Math.random() * 50) + 10, 0, 0);

        await db.insert(attendanceLogs).values({
          userId: user.id,
          timestamp: checkInTime,
          type: "check_in",
          status: isLate ? "late" : "on_time",
          confidenceScore: 0.93 + Math.random() * 0.06,
          verificationMethod: "facial_live",
          snapshotUrl: user.photoUrl,
          deviceInfo: "Main Terminal Kiosk #1",
          locationTag: "Apex HQ - Lobby Portal A",
          createdAt: checkInTime,
        });

        const checkOutTime = new Date(pastDate);
        checkOutTime.setHours(17 + Math.floor(Math.random() * 2), Math.floor(Math.random() * 59), 0, 0);
        await db.insert(attendanceLogs).values({
          userId: user.id,
          timestamp: checkOutTime,
          type: "check_out",
          status: "on_time",
          confidenceScore: 0.94 + Math.random() * 0.05,
          verificationMethod: "facial_live",
          snapshotUrl: user.photoUrl,
          deviceInfo: "Main Terminal Kiosk #1",
          locationTag: "Apex HQ - Exit Gate 1",
          createdAt: checkOutTime,
        });
      }
    }

    return NextResponse.json({
      success: true,
      message: "Database reset and seeded with fresh sample data!",
    });
  } catch (error: unknown) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to seed data" },
      { status: 500 }
    );
  }
}
