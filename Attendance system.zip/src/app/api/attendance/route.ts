import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, attendanceLogs, systemSettings } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { desc, eq, and, gte, lte } from "drizzle-orm";
import { matchFaceEmbedding, DEFAULT_CONFIDENCE_THRESHOLD } from "@/lib/face-recognition";

export async function GET(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const searchParams = req.nextUrl.searchParams;
    const dateFilter = searchParams.get("date") || "today"; // 'today' | '7days' | '30days' | 'all' | 'YYYY-MM-DD'
    const status = searchParams.get("status"); // 'on_time' | 'late' | 'check_out'
    const department = searchParams.get("department");
    const query = searchParams.get("q") || "";
    const limit = parseInt(searchParams.get("limit") || "100", 10);

    // Fetch all logs joined with users
    const allLogs = await db
      .select({
        id: attendanceLogs.id,
        userId: attendanceLogs.userId,
        timestamp: attendanceLogs.timestamp,
        type: attendanceLogs.type,
        status: attendanceLogs.status,
        confidenceScore: attendanceLogs.confidenceScore,
        verificationMethod: attendanceLogs.verificationMethod,
        snapshotUrl: attendanceLogs.snapshotUrl,
        deviceInfo: attendanceLogs.deviceInfo,
        locationTag: attendanceLogs.locationTag,
        notes: attendanceLogs.notes,
        createdAt: attendanceLogs.createdAt,
        user: {
          id: users.id,
          employeeId: users.employeeId,
          name: users.name,
          email: users.email,
          role: users.role,
          department: users.department,
          photoUrl: users.photoUrl,
          shiftStart: users.shiftStart,
          shiftEnd: users.shiftEnd,
        },
      })
      .from(attendanceLogs)
      .innerJoin(users, eq(attendanceLogs.userId, users.id))
      .orderBy(desc(attendanceLogs.timestamp))
      .limit(limit);

    // Filter by date
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);

    let filtered = allLogs;

    if (dateFilter === "today") {
      filtered = filtered.filter((log) => new Date(log.timestamp) >= todayStart);
    } else if (dateFilter === "7days") {
      const past7 = new Date(todayStart);
      past7.setDate(past7.getDate() - 7);
      filtered = filtered.filter((log) => new Date(log.timestamp) >= past7);
    } else if (dateFilter === "30days") {
      const past30 = new Date(todayStart);
      past30.setDate(past30.getDate() - 30);
      filtered = filtered.filter((log) => new Date(log.timestamp) >= past30);
    } else if (dateFilter !== "all" && /^\d{4}-\d{2}-\d{2}$/.test(dateFilter)) {
      const [y, m, d] = dateFilter.split("-").map(Number);
      const targetStart = new Date(y, m - 1, d, 0, 0, 0, 0);
      const targetEnd = new Date(y, m - 1, d, 23, 59, 59, 999);
      filtered = filtered.filter(
        (log) => new Date(log.timestamp) >= targetStart && new Date(log.timestamp) <= targetEnd
      );
    }

    if (status && status !== "all") {
      if (status === "check_out") {
        filtered = filtered.filter((l) => l.type === "check_out");
      } else {
        filtered = filtered.filter((l) => l.status === status && l.type === "check_in");
      }
    }

    if (department && department !== "all") {
      filtered = filtered.filter((l) => l.user.department === department);
    }

    if (query) {
      const q = query.toLowerCase();
      filtered = filtered.filter(
        (l) =>
          l.user.name.toLowerCase().includes(q) ||
          l.user.employeeId.toLowerCase().includes(q) ||
          l.user.department.toLowerCase().includes(q) ||
          (l.locationTag && l.locationTag.toLowerCase().includes(q))
      );
    }

    return NextResponse.json({
      success: true,
      logs: filtered,
      total: filtered.length,
    });
  } catch (error: unknown) {
    console.error("GET /api/attendance error:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to fetch attendance logs" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await req.json();
    const {
      faceEmbedding,
      snapshotUrl,
      type = "check_in", // 'check_in' | 'check_out'
      locationTag = "Main Entrance Terminal",
      deviceInfo = "Kiosk Face Scanner",
      manualUserId,
      overrideNotes,
    } = body;

    // Fetch system settings
    const settingsList = await db.select().from(systemSettings).limit(1);
    const settings = settingsList[0] || {
      confidenceThreshold: DEFAULT_CONFIDENCE_THRESHOLD,
      gracePeriodMinutes: 15,
      workStartTime: "09:00",
    };

    let matchedUserId: number | null = null;
    let confidenceScore = 0.95;
    let verificationMethod = "facial_live";
    let matchedUser = null;

    if (manualUserId) {
      // Manual Admin Override
      const userList = await db.select().from(users).where(eq(users.id, Number(manualUserId)));
      if (userList.length === 0) {
        return NextResponse.json({ success: false, error: "Employee not found." }, { status: 404 });
      }
      matchedUser = userList[0];
      matchedUserId = matchedUser.id;
      confidenceScore = 1.0;
      verificationMethod = "manual_override";
    } else {
      // Biometric Facial Recognition
      if (!faceEmbedding || !Array.isArray(faceEmbedding) || faceEmbedding.length === 0) {
        return NextResponse.json(
          {
            success: false,
            error: "No facial embedding received. Please ensure your face is clearly visible in front of the camera.",
          },
          { status: 400 }
        );
      }

      // Fetch all registered active users
      const allActiveUsers = await db.select().from(users).where(eq(users.isActive, true));

      if (allActiveUsers.length === 0) {
        return NextResponse.json(
          { success: false, error: "No registered employees found. Please register an employee first." },
          { status: 404 }
        );
      }

      const match = matchFaceEmbedding(faceEmbedding, allActiveUsers, settings.confidenceThreshold);

      if (match.status !== "success" || !match.matchedUser) {
        return NextResponse.json({
          success: false,
          status: match.status,
          confidence: match.confidence,
          allScores: match.allScores.slice(0, 3),
          message:
            match.status === "low_confidence"
              ? `Face matched with low confidence (${Math.round(match.confidence * 100)}%). Please look straight into the camera with good lighting.`
              : "Face not recognized. Unregistered biometric signature.",
        });
      }

      matchedUser = match.matchedUser;
      matchedUserId = match.matchedUser.id;
      confidenceScore = match.confidence;
    }

    // Determine Status (on_time vs late vs check_out)
    const now = new Date();
    let status = "on_time";

    if (type === "check_in") {
      const shiftStartTimeStr = matchedUser.shiftStart || settings.workStartTime || "09:00";
      const [shiftHour, shiftMin] = shiftStartTimeStr.split(":").map(Number);
      const shiftGrace = settings.gracePeriodMinutes || 15;

      const expectedTime = new Date(now);
      expectedTime.setHours(shiftHour, shiftMin + shiftGrace, 0, 0);

      if (now > expectedTime) {
        status = "late";
      } else {
        status = "on_time";
      }
    } else {
      status = "on_time";
    }

    // Insert attendance log record
    const [newLog] = await db
      .insert(attendanceLogs)
      .values({
        userId: matchedUserId,
        timestamp: now,
        type,
        status,
        confidenceScore: Math.round(confidenceScore * 1000) / 1000,
        verificationMethod,
        snapshotUrl: snapshotUrl || matchedUser.photoUrl,
        deviceInfo,
        locationTag,
        notes: overrideNotes || (type === "check_in" ? `Verified via Facial Biometrics (${(confidenceScore * 100).toFixed(1)}%)` : "Departure recorded"),
      })
      .returning();

    return NextResponse.json({
      success: true,
      log: newLog,
      user: {
        id: matchedUser.id,
        employeeId: matchedUser.employeeId,
        name: matchedUser.name,
        role: matchedUser.role,
        department: matchedUser.department,
        photoUrl: matchedUser.photoUrl,
        shiftStart: matchedUser.shiftStart,
        shiftEnd: matchedUser.shiftEnd,
      },
      confidence: confidenceScore,
      status,
      timestamp: now.toISOString(),
      formattedTime: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
      message: `${type === "check_in" ? "Check-In" : "Check-Out"} Successful! Welcome ${matchedUser.name}.`,
    });
  } catch (error: unknown) {
    console.error("POST /api/attendance error:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to record attendance" },
      { status: 500 }
    );
  }
}
