export interface AttendanceUser {
  id: number;
  employeeId: string;
  name: string;
  email: string;
  role: string;
  department: string;
  photoUrl: string | null;
  shiftStart?: string;
  shiftEnd?: string;
}

export interface AttendanceRecord {
  id: number;
  userId: number;
  timestamp: string;
  type: string;
  status: string;
  confidenceScore: number;
  verificationMethod: string;
  snapshotUrl: string | null;
  deviceInfo?: string | null;
  locationTag: string | null;
  notes: string | null;
  user: AttendanceUser;
}

export interface AdminSession {
  id: number;
  employeeId: string;
  name: string;
  email: string;
  role: string;
  department: string;
  photoUrl: string | null;
}

export type AppTab = "checkin" | "dashboard" | "records" | "register" | "employees" | "settings";
