"use client";

import React, { useState } from "react";
import { ShieldCheck, KeyRound, RefreshCw, AlertCircle, Scan, Lock } from "lucide-react";
import { setAdminSession } from "@/lib/admin-session";
import type { AdminSession } from "@/lib/types";

export default function AdminLogin({
  onSuccess,
  onCancel,
}: {
  onSuccess: (admin: AdminSession) => void;
  onCancel?: () => void;
}) {
  const [identifier, setIdentifier] = useState("ADMIN-001");
  const [pinCode, setPinCode] = useState("1234");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, pinCode }),
      });
      const data = await res.json();
      if (!data.success || !data.admin) {
        setError(data.error || "Access denied.");
        return;
      }
      setAdminSession(data.admin);
      onSuccess(data.admin);
    } catch {
      setError("Unable to reach the authentication service.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-slate-900/90 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-cyan-600/20 via-slate-900 to-blue-600/20 p-6 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white">Administrator Access</h1>
              <p className="text-xs text-slate-400">Unlock all attendance records, FRS enrollment, and exports</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="flex items-start space-x-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Admin ID or Email</label>
            <div className="relative">
              <Scan className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-xl pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:border-cyan-500"
                placeholder="ADMIN-001"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Security PIN</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-xl pl-9 pr-3 py-2.5 text-sm focus:outline-none focus:border-cyan-500"
                placeholder="••••"
              />
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-400 space-y-1 font-mono">
            <p className="text-cyan-400 font-semibold flex items-center space-x-1">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Demo administrator credentials</span>
            </p>
            <p>ID: ADMIN-001  •  PIN: 1234</p>
            <p>HR Admin: EMP-1004  •  PIN: 1004</p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center space-x-2 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-extrabold text-sm hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
            <span>{loading ? "Verifying..." : "Enter Admin Console"}</span>
          </button>

          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="w-full py-2 text-xs text-slate-400 hover:text-white"
            >
              Return to Face Check-In
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
