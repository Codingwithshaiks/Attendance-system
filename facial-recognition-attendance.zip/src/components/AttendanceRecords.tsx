"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  Search,
  RefreshCw,
  FileSpreadsheet,
  FileText,
  Eye,
  ChevronLeft,
  ChevronRight,
  UserPlus,
  ClipboardList,
  AlertTriangle,
  CheckCircle2,
  Filter,
  CalendarRange,
} from "lucide-react";
import type { AttendanceRecord } from "@/lib/types";
import { exportAttendanceExcel, exportAttendancePortraitPdf } from "@/lib/export-reports";

const DEPTS = [
  "all",
  "Engineering",
  "Product & Design",
  "Human Resources",
  "Operations",
  "Marketing",
  "Sales",
];

export default function AttendanceRecords({
  adminName,
  orgName,
  onRegisterEmployee,
}: {
  adminName?: string;
  orgName?: string;
  onRegisterEmployee: () => void;
}) {
  const [logs, setLogs] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [deptFilter, setDeptFilter] = useState("all");
  const [selectedSnapshot, setSelectedSnapshot] = useState<AttendanceRecord | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [exporting, setExporting] = useState<"pdf" | "xlsx" | null>(null);
  const itemsPerPage = 12;

  useEffect(() => {
    fetchRecords();
  }, [dateFilter, fromDate, toDate]);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("limit", "5000");
      if (fromDate || toDate) {
        params.set("date", "all");
        if (fromDate) params.set("from", fromDate);
        if (toDate) params.set("to", toDate);
      } else {
        params.set("date", dateFilter);
      }
      const res = await fetch(`/api/attendance?${params.toString()}`);
      const data = await res.json();
      if (data.success) setLogs(data.logs || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      const q = searchQuery.toLowerCase();
      const matchQuery =
        !searchQuery ||
        log.user?.name.toLowerCase().includes(q) ||
        log.user?.employeeId.toLowerCase().includes(q) ||
        log.user?.email?.toLowerCase().includes(q) ||
        log.user?.department.toLowerCase().includes(q) ||
        (log.locationTag && log.locationTag.toLowerCase().includes(q));

      const matchStatus =
        statusFilter === "all" ||
        (statusFilter === "check_out" && log.type === "check_out") ||
        (statusFilter === "on_time" && log.status === "on_time" && log.type === "check_in") ||
        (statusFilter === "late" && log.status === "late" && log.type === "check_in");

      const matchDept = deptFilter === "all" || log.user?.department === deptFilter;
      return matchQuery && matchStatus && matchDept;
    });
  }, [logs, searchQuery, statusFilter, deptFilter]);

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage) || 1;
  const paginatedLogs = filteredLogs.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const dateRangeLabel = fromDate || toDate
    ? `${fromDate || "start"} to ${toDate || "today"}`
    : dateFilter === "today"
    ? "Today"
    : dateFilter === "7days"
    ? "Last 7 Days"
    : dateFilter === "30days"
    ? "Last 30 Days"
    : "Full History";

  const exportMeta = {
    organizationName: orgName || "Apex Cybernetics HQ",
    dateRangeLabel,
    generatedBy: adminName || "Administrator",
  };

  const handleExportPdf = () => {
    setExporting("pdf");
    try {
      exportAttendancePortraitPdf(filteredLogs, exportMeta);
    } finally {
      setTimeout(() => setExporting(null), 400);
    }
  };

  const handleExportExcel = () => {
    setExporting("xlsx");
    try {
      exportAttendanceExcel(filteredLogs, exportMeta);
    } finally {
      setTimeout(() => setExporting(null), 400);
    }
  };

  const checkIns = filteredLogs.filter((l) => l.type === "check_in").length;
  const lateCount = filteredLogs.filter((l) => l.type === "check_in" && l.status === "late").length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center space-x-2">
            <ClipboardList className="w-5 h-5 text-cyan-400" />
            <h1 className="text-2xl font-black text-white tracking-tight">All Attendance Records</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              Admin Archive
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Complete biometric check-in history. Export filtered results as portrait PDF or Excel workbook.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onRegisterEmployee}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 text-xs font-extrabold hover:from-cyan-400"
          >
            <UserPlus className="w-4 h-4" />
            <span>Register via FRS Scan</span>
          </button>
          <button
            onClick={handleExportPdf}
            disabled={exporting !== null}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700 border border-slate-700"
          >
            <FileText className="w-4 h-4 text-rose-400" />
            <span>{exporting === "pdf" ? "Building PDF..." : "Portrait PDF"}</span>
          </button>
          <button
            onClick={handleExportExcel}
            disabled={exporting !== null}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold hover:bg-slate-700 border border-slate-700"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>{exporting === "xlsx" ? "Building Excel..." : "Excel Workbook"}</span>
          </button>
          <button
            onClick={fetchRecords}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin text-cyan-400" : ""}`} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
          <p className="text-[11px] uppercase tracking-wider text-slate-400">Filtered Records</p>
          <p className="text-2xl font-black text-white">{filteredLogs.length}</p>
        </div>
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
          <p className="text-[11px] uppercase tracking-wider text-slate-400">Check-Ins</p>
          <p className="text-2xl font-black text-emerald-400">{checkIns}</p>
        </div>
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
          <p className="text-[11px] uppercase tracking-wider text-slate-400">Late Arrivals</p>
          <p className="text-2xl font-black text-amber-400">{lateCount}</p>
        </div>
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
          <p className="text-[11px] uppercase tracking-wider text-slate-400">Period</p>
          <p className="text-sm font-bold text-cyan-300 mt-1">{dateRangeLabel}</p>
        </div>
      </div>

      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 overflow-hidden">
        <div className="p-4 border-b border-slate-800 space-y-3">
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <Filter className="w-4 h-4 text-cyan-400" />
            <span>Search, date range, status, and department filters apply to on-screen data and exports.</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-4 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search name, employee ID, email, department..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-xl pl-9 pr-3 py-2 text-xs focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div className="md:col-span-2">
              <select
                value={dateFilter}
                onChange={(e) => {
                  setDateFilter(e.target.value);
                  setFromDate("");
                  setToDate("");
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-xl px-3 py-2 text-xs"
              >
                <option value="all">All History</option>
                <option value="today">Today</option>
                <option value="7days">Last 7 Days</option>
                <option value="30days">Last 30 Days</option>
              </select>
            </div>
            <div className="md:col-span-2 flex items-center space-x-1">
              <CalendarRange className="w-3.5 h-3.5 text-slate-500 hidden sm:block" />
              <input
                type="date"
                value={fromDate}
                onChange={(e) => {
                  setFromDate(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-xl px-2 py-2 text-xs"
              />
            </div>
            <div className="md:col-span-2">
              <input
                type="date"
                value={toDate}
                onChange={(e) => {
                  setToDate(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-xl px-2 py-2 text-xs"
              />
            </div>
            <div className="md:col-span-1">
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-xl px-2 py-2 text-xs"
              >
                <option value="all">Status</option>
                <option value="on_time">On-Time</option>
                <option value="late">Late</option>
                <option value="check_out">Check-Out</option>
              </select>
            </div>
            <div className="md:col-span-1">
              <select
                value={deptFilter}
                onChange={(e) => {
                  setDeptFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-950 border border-slate-800 text-slate-300 rounded-xl px-2 py-2 text-xs"
              >
                {DEPTS.map((d) => (
                  <option key={d} value={d}>
                    {d === "all" ? "Dept" : d}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Date & Time</th>
                <th className="py-3 px-4">Type / Status</th>
                <th className="py-3 px-4">Match</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4 text-right">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {paginatedLogs.map((log) => {
                const d = new Date(log.timestamp);
                return (
                  <tr key={log.id} className="hover:bg-slate-800/40">
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-3">
                        <img
                          src={log.snapshotUrl || log.user?.photoUrl || ""}
                          alt={log.user?.name}
                          className="w-9 h-9 rounded-xl object-cover border border-slate-700"
                        />
                        <div>
                          <div className="font-bold text-white">{log.user?.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{log.user?.employeeId}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-200">{log.user?.department}</div>
                      <div className="text-[10px] text-slate-400">{log.user?.role}</div>
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <div className="text-white font-semibold">
                        {d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {d.toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {log.type === "check_out" ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                          Check-Out
                        </span>
                      ) : log.status === "late" ? (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/30">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Late</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>On-Time</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono text-cyan-300 font-bold">
                      {((log.confidenceScore || 0) * 100).toFixed(1)}%
                    </td>
                    <td className="py-3 px-4 text-[11px] font-mono text-slate-400 max-w-[180px] truncate">
                      {log.locationTag || "HQ Terminal"}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedSnapshot(log)}
                        className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-cyan-400"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {paginatedLogs.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-500">
                    {loading ? "Loading attendance archive..." : "No records match the current filters."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div>
            Showing{" "}
            <strong className="text-white">
              {filteredLogs.length ? (currentPage - 1) * itemsPerPage + 1 : 0}
            </strong>{" "}
            – <strong className="text-white">{Math.min(currentPage * itemsPerPage, filteredLogs.length)}</strong> of{" "}
            <strong className="text-white">{filteredLogs.length}</strong>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg bg-slate-950 border border-slate-800 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono text-white">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg bg-slate-950 border border-slate-800 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {selectedSnapshot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white">Attendance Audit Record</h3>
              <button onClick={() => setSelectedSnapshot(null)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>
            <img
              src={selectedSnapshot.snapshotUrl || selectedSnapshot.user?.photoUrl || ""}
              alt={selectedSnapshot.user?.name}
              className="w-full h-56 object-cover rounded-xl border border-cyan-500/40"
            />
            <div className="text-center">
              <h4 className="text-lg font-extrabold text-white">{selectedSnapshot.user?.name}</h4>
              <p className="text-xs text-cyan-400 font-mono">
                {selectedSnapshot.user?.employeeId} • {selectedSnapshot.user?.department}
              </p>
            </div>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Timestamp</span>
                <span className="text-white">{new Date(selectedSnapshot.timestamp).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Match</span>
                <span className="text-emerald-400 font-bold">
                  {((selectedSnapshot.confidenceScore || 0) * 100).toFixed(2)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Status</span>
                <span className="text-white uppercase">{selectedSnapshot.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Method</span>
                <span className="text-white">{selectedSnapshot.verificationMethod}</span>
              </div>
            </div>
            <button
              onClick={() => setSelectedSnapshot(null)}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
