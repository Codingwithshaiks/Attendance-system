"use client";

import React, { useState, useEffect } from "react";
import {
  Scan,
  LayoutDashboard,
  UserPlus,
  Users,
  Settings,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  ShieldCheck,
  ClipboardList,
  LogOut,
  Lock,
} from "lucide-react";
import { soundEffects } from "@/lib/audio";
import type { AdminSession, AppTab } from "@/lib/types";

interface NavbarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  orgName?: string;
  admin?: AdminSession | null;
  onAdminLogin: () => void;
  onAdminLogout: () => void;
}

const ADMIN_TABS: AppTab[] = ["dashboard", "records", "register", "employees", "settings"];

export default function Navbar({
  activeTab,
  setActiveTab,
  orgName = "ApexVision FRS",
  admin,
  onAdminLogin,
  onAdminLogout,
}: NavbarProps) {
  const [currentTime, setCurrentTime] = useState<string>("");
  const [currentDate, setCurrentDate] = useState<string>("");
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      setCurrentDate(now.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric", year: "numeric" }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundEffects.setSoundEnabled(next);
    if (next) soundEffects.playScanPing();
  };

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const requestTab = (tab: AppTab) => {
    if (ADMIN_TABS.includes(tab) && !admin) {
      onAdminLogin();
      return;
    }
    setActiveTab(tab);
  };

  const tabClass = (tab: AppTab) =>
    `flex items-center space-x-1.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-all ${
      activeTab === tab
        ? "bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25 font-semibold"
        : "text-slate-300 hover:text-white hover:bg-slate-800/60"
    }`;

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab("checkin")}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/20 text-white font-bold">
              <Scan className="w-5 h-5 animate-pulse" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-cyan-300 bg-clip-text text-transparent">
                  {orgName}
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  FRS Live
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono hidden sm:block">AI Biometric Attendance Portal</p>
            </div>
          </div>

          <nav className="hidden lg:flex items-center space-x-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
            <button onClick={() => requestTab("checkin")} className={tabClass("checkin")}>
              <Scan className="w-4 h-4" />
              <span>Check-In</span>
            </button>
            <button onClick={() => requestTab("dashboard")} className={tabClass("dashboard")}>
              <LayoutDashboard className="w-4 h-4" />
              <span>Dashboard</span>
              {!admin && <Lock className="w-3 h-3 opacity-60" />}
            </button>
            <button onClick={() => requestTab("records")} className={tabClass("records")}>
              <ClipboardList className="w-4 h-4" />
              <span>All Records</span>
              {!admin && <Lock className="w-3 h-3 opacity-60" />}
            </button>
            <button onClick={() => requestTab("register")} className={tabClass("register")}>
              <UserPlus className="w-4 h-4" />
              <span>FRS Enroll</span>
              {!admin && <Lock className="w-3 h-3 opacity-60" />}
            </button>
            <button onClick={() => requestTab("employees")} className={tabClass("employees")}>
              <Users className="w-4 h-4" />
              <span>Staff</span>
            </button>
            <button onClick={() => requestTab("settings")} className={tabClass("settings")}>
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>
          </nav>

          <div className="flex items-center space-x-2">
            <div className="hidden xl:flex flex-col items-end px-3 py-1 bg-slate-950/80 rounded-lg border border-slate-800 text-right font-mono">
              <span className="text-sm font-bold text-cyan-400 tracking-wider">{currentTime || "--:--:--"}</span>
              <span className="text-[10px] text-slate-400">{currentDate}</span>
            </div>

            {admin ? (
              <div className="flex items-center space-x-2 pl-1">
                <img
                  src={admin.photoUrl || ""}
                  alt={admin.name}
                  className="w-8 h-8 rounded-lg object-cover border border-cyan-500/40 hidden sm:block"
                />
                <div className="hidden md:block text-right">
                  <p className="text-[11px] font-bold text-white leading-tight">{admin.name.split(" ")[0]}</p>
                  <p className="text-[9px] text-cyan-400 font-mono">ADMIN</p>
                </div>
                <button
                  onClick={onAdminLogout}
                  title="Sign out of admin console"
                  className="p-2 rounded-lg bg-slate-800/80 text-rose-300 border border-slate-700 hover:bg-slate-700"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onAdminLogin}
                className="flex items-center space-x-1.5 px-3 py-2 rounded-lg bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 text-xs font-bold hover:bg-cyan-500/20"
              >
                <ShieldCheck className="w-4 h-4" />
                <span className="hidden sm:inline">Admin Login</span>
              </button>
            )}

            <button
              onClick={handleToggleSound}
              className={`p-2 rounded-lg border ${
                soundEnabled
                  ? "bg-slate-800/80 text-cyan-400 border-slate-700"
                  : "bg-slate-900 text-slate-500 border-slate-800"
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={handleToggleFullscreen}
              className="p-2 rounded-lg bg-slate-800/80 text-slate-300 border border-slate-700 hidden sm:inline-flex"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="flex lg:hidden items-center justify-around py-2 border-t border-slate-800 text-[10px]">
          <button onClick={() => requestTab("checkin")} className={activeTab === "checkin" ? "text-cyan-400 font-bold" : "text-slate-400"}>
            <Scan className="w-4 h-4 mx-auto mb-0.5" />
            Check-In
          </button>
          <button onClick={() => requestTab("records")} className={activeTab === "records" ? "text-cyan-400 font-bold" : "text-slate-400"}>
            <ClipboardList className="w-4 h-4 mx-auto mb-0.5" />
            Records
          </button>
          <button onClick={() => requestTab("register")} className={activeTab === "register" ? "text-cyan-400 font-bold" : "text-slate-400"}>
            <UserPlus className="w-4 h-4 mx-auto mb-0.5" />
            Enroll
          </button>
          <button onClick={() => requestTab("dashboard")} className={activeTab === "dashboard" ? "text-cyan-400 font-bold" : "text-slate-400"}>
            <LayoutDashboard className="w-4 h-4 mx-auto mb-0.5" />
            Admin
          </button>
          <button onClick={() => requestTab("employees")} className={activeTab === "employees" ? "text-cyan-400 font-bold" : "text-slate-400"}>
            <Users className="w-4 h-4 mx-auto mb-0.5" />
            Staff
          </button>
        </div>
      </div>
    </header>
  );
}
