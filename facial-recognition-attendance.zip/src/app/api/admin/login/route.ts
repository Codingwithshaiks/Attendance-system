import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, systemSettings } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq, or } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await req.json();
    const identifier = String(body.identifier || body.employeeId || body.email || "").trim();
    const pinCode = String(body.pinCode || body.password || "").trim();

    if (!identifier || !pinCode) {
      return NextResponse.json(
        { success: false, error: "Admin ID and PIN are required." },
        { status: 400 }
      );
    }

    const matches = await db
      .select()
      .from(users)
      .where(or(eq(users.employeeId, identifier), eq(users.email, identifier.toLowerCase())));

    const user = matches[0];
    if (!user || !user.isActive) {
      return NextResponse.json(
        { success: false, error: "Admin account not found. Use ADMIN-001 or elena.rostova@apextech.io." },
        { status: 401 }
      );
    }

    const settings = await db.select().from(systemSettings).limit(1);
    const masterPin = settings[0]?.kioskModePasscode || "1234";
    const pinOk = user.pinCode === pinCode || pinCode === masterPin;

    if (!pinOk) {
      return NextResponse.json(
        { success: false, error: "Invalid PIN. Try 1234 for the system administrator." },
        { status: 401 }
      );
    }

    if (!user.isAdmin) {
      return NextResponse.json(
        { success: false, error: "This account does not have administrator privileges." },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      admin: {
        id: user.id,
        employeeId: user.employeeId,
        name: user.name,
        email: user.email,
        role: user.role,
        department: user.department,
        photoUrl: user.photoUrl,
      },
      message: `Welcome back, ${user.name}.`,
    });
  } catch (error: unknown) {
    console.error("POST /api/admin/login error:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Login failed" },
      { status: 500 }
    );
  }
}
