"use client";

import React, { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import FacialCheckIn from "@/components/FacialCheckIn";
import AdminDashboard from "@/components/AdminDashboard";
import UserRegistration from "@/components/UserRegistration";
import EmployeeDirectory from "@/components/EmployeeDirectory";
import KioskSettings from "@/components/KioskSettings";
import AttendanceRecords from "@/components/AttendanceRecords";
import AdminLogin from "@/components/AdminLogin";
import { ShieldCheck } from "lucide-react";
import { clearAdminSession, getAdminSession } from "@/lib/admin-session";
import type { AdminSession, AppTab } from "@/lib/types";

const ADMIN_TABS: AppTab[] = ["dashboard", "records", "register", "employees", "settings"];

export default function Home() {
  const [activeTab, setActiveTab] = useState<AppTab>("checkin");
  const [pendingTab, setPendingTab] = useState<AppTab | null>(null);
  const [orgName, setOrgName] = useState("ApexVision FRS");
  const [admin, setAdmin] = useState<AdminSession | null>(null);
  const [showLogin, setShowLogin] = useState(false);

  useEffect(() => {
    setAdmin(getAdminSession());
    fetch("/api/settings")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.settings?.organizationName) {
          setOrgName(data.settings.organizationName);
        }
      })
      .catch(() => {});
  }, []);

  const handleSetTab = (tab: AppTab) => {
    if (ADMIN_TABS.includes(tab) && !admin) {
      setPendingTab(tab);
      setShowLogin(true);
      return;
    }
    setShowLogin(false);
    setActiveTab(tab);
  };

  const handleLoginSuccess = (session: AdminSession) => {
    setAdmin(session);
    setShowLogin(false);
    setActiveTab(pendingTab || "records");
    setPendingTab(null);
  };

  const handleLogout = () => {
    clearAdminSession();
    setAdmin(null);
    setShowLogin(false);
    setActiveTab("checkin");
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#080d1a] bg-gradient-to-b from-[#080d1a] via-[#0d1424] to-[#080d1a] text-slate-100">
      <Navbar
        activeTab={showLogin ? activeTab : activeTab}
        setActiveTab={handleSetTab}
        orgName={orgName}
        admin={admin}
        onAdminLogin={() => {
          setPendingTab("records");
          setShowLogin(true);
        }}
        onAdminLogout={handleLogout}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {showLogin && !admin ? (
          <AdminLogin
            onSuccess={handleLoginSuccess}
            onCancel={() => {
              setShowLogin(false);
              setPendingTab(null);
              setActiveTab("checkin");
            }}
          />
        ) : (
          <>
            {activeTab === "checkin" && (
              <FacialCheckIn
                onSwitchToDashboard={() => handleSetTab("dashboard")}
                onSwitchToRegister={() => handleSetTab("register")}
              />
            )}
            {activeTab === "dashboard" && admin && (
              <AdminDashboard
                onSwitchToRegister={() => handleSetTab("register")}
                onSwitchToCheckIn={() => setActiveTab("checkin")}
                onSwitchToRecords={() => setActiveTab("records")}
                adminName={admin.name}
                orgName={orgName}
              />
            )}
            {activeTab === "records" && admin && (
              <AttendanceRecords
                adminName={admin.name}
                orgName={orgName}
                onRegisterEmployee={() => setActiveTab("register")}
              />
            )}
            {activeTab === "register" && admin && <UserRegistration requireFrsScan />}
            {activeTab === "employees" && admin && (
              <EmployeeDirectory
                onAddNew={() => setActiveTab("register")}
                onTestUser={() => setActiveTab("checkin")}
              />
            )}
            {activeTab === "settings" && admin && <KioskSettings />}
          </>
        )}
      </main>

      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-4 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-mono text-[11px] text-slate-300">
              FRS Biometric Core v2.7 • Admin archive, portrait PDF & Excel export online
            </span>
          </div>
          <div className="flex items-center space-x-4 text-[11px] font-mono text-slate-400">
            <span className="flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Admin-gated records • AES-256 vectors</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
