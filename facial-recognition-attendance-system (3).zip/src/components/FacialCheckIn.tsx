"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import CameraStage, { type CameraHandle, type CamState } from "@/components/CameraStage";
import { IconBolt, IconCheck, IconClock, IconClose, IconEnter, IconExit, IconShield, IconUsers, IconWarn } from "@/components/Icons";
import { Avatar, Meter, Panel, PanelHead, Pill, ToastStack } from "@/components/ui";
import { checkIn, fetchFeed, queuedCount, saveLastResult, type CheckInResponse } from "@/lib/api";
import { playTone, useCountUp, useLiveFeed, useNow, useReveal, useToasts } from "@/lib/hooks";
import { formatClock, initials, relativeTime, statusMeta } from "@/lib/shared";

type Phase = "idle" | "align" | "extract" | "match" | "done";

const PHASES: { key: Phase; label: string; detail: string }[] = [
  { key: "align", label: "Face lock", detail: "chrominance projection + landmark box" },
  { key: "extract", label: "Embed", detail: "96² patch → 512-d HOG + 256-d residual" },
  { key: "match", label: "1:N gallery scan", detail: "cosine fusion, threshold gate" },
  { key: "done", label: "Ledger write", detail: "attendance log + roster update" },
];

export default function FacialCheckIn() {
  const cam = useRef<CameraHandle | null>(null);
  const [camState, setCamState] = useState<CamState>("idle");
  const [scanning, setScanning] = useState(false);
  const [phase, setPhase] = useState<Phase>("idle");
  const [mode, setMode] = useState<"check_in" | "check_out">("check_in");
  const [result, setResult] = useState<(CheckInResponse & { at: number }) | null>(null);
  const [autoScan, setAutoScan] = useState(false);
  const [log, setLog] = useState<{ t: number; text: string; tone: string }[]>([]);
  const [quality, setQuality] = useState(0);
  const [motion, setMotion] = useState(0);
  const [faceLocked, setFaceLocked] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const now = useNow(1000);
  const { toasts, push, dismiss } = useToasts();
  const feed = useLiveFeed(() => fetchFeed(), { interval: 7000, channel: "frs-live" });
  const [queued, setQueued] = useState(0);

  useReveal([feed.updatedAt]);

  const totals = feed.data?.totals;
  const present = useCountUp(totals?.present ?? 0);
  const gallery = feed.data?.roster.length ?? 0;

  const pushLog = useCallback((text: string, tone = "scan") => {
    setLog((l) => [{ t: Date.now(), text, tone }, ...l].slice(0, 8));
  }, []);

  useEffect(() => setQueued(queuedCount()), [result]);

  const runScan = useCallback(async () => {
    if (scanning || cam.current?.state() !== "live") return;
    setScanning(true);
    setResult(null);
    setPhase("align");
    pushLog("frame grabbed · exposure lock", "scan");
    const cap = await cam.current?.capture();
    if (!cap) {
      setScanning(false);
      setPhase("idle");
      pushLog("capture aborted · sensor idle", "stop");
      return;
    }
    if (cap.quality.overall < 0.28) {
      setPhase("done");
      setResult({ ok: false, reason: "Signal quality too low", hint: "Light your face and hold steady — quality gate rejected the frame before matching.", score: 0, threshold: feed.data?.config.matchThreshold ?? 0.72, margin: 0, latencyMs: 0, at: Date.now() });
      playTone(false);
      setScanning(false);
      setPhase("idle");
      pushLog(`quality gate rejected frame (${(cap.quality.overall * 100).toFixed(0)}%)`, "stop");
      return;
    }
    await new Promise((r) => setTimeout(r, 260));
    setPhase("extract");
    pushLog(`patch ok · sig ${(cap.quality.overall * 100).toFixed(0)}% · motion ${(cap.motion * 100).toFixed(0)}%`, "scan");
    await new Promise((r) => setTimeout(r, 240));
    setPhase("match");
    try {
      const res = await checkIn({
        template: cap.template,
        event: mode,
        quality: cap.quality.overall,
        liveness: cap.motion,
        snapshot: cap.review,
        device: `kiosk-${(navigator.userAgent || "web").slice(0, 10).toLowerCase()}`,
      });
      const stamped = { ...res, at: Date.now() };
      setResult(stamped);
      saveLastResult({ name: stamped.user?.name ?? null, at: stamped.at, score: stamped.score, ok: stamped.ok });
      setPhase("done");
      playTone(stamped.ok);
      feed.broadcast();
      pushLog(
        stamped.ok
          ? `MATCH ${stamped.user?.name ?? "identity"} · ${stamped.score.toFixed(3)} ≥ ${(stamped.threshold ?? 0.72).toFixed(2)}`
          : `NO-MATCH · best ${stamped.score?.toFixed(3) ?? "0.000"} < ${(stamped.threshold ?? 0.72).toFixed(2)}`,
        stamped.ok ? "go" : "stop",
      );
      if (stamped.offline) push("Offline verdict", "Served from the on-device template mirror; queued for replay.", "signal");
      else if (stamped.ok)
        push(
          stamped.duplicate ? "Repeat scan noted" : mode === "check_out" ? "Checked out" : "Attendance recorded",
          `${stamped.user?.name} · confidence ${(stamped.score * 100).toFixed(1)}%`,
          "go",
        );
      else push("Access denied", stamped.reason ?? "Face not recognised", "stop");
      setCooldown(6);
    } catch (e) {
      const message = e instanceof Error ? e.message : "Verification service unreachable";
      setResult({ ok: false, reason: "Verifier offline", hint: message, score: 0, threshold: 0, margin: 0, latencyMs: 0, at: Date.now() });
      pushLog(`verifier error · ${message}`, "stop");
      playTone(false);
      setPhase("done");
    } finally {
      setScanning(false);
    }
  }, [feed, mode, push, pushLog, scanning]);

  // auto-dismiss the result card so the kiosk is ready for the next person
  useEffect(() => {
    if (!result) return;
    const id = window.setTimeout(() => {
      setResult(null);
      setPhase("idle");
    }, 12000);
    return () => window.clearTimeout(id);
  }, [result]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = window.setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => window.clearTimeout(id);
  }, [cooldown]);

  // hotkeys
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key.toLowerCase() === "s") {
        e.preventDefault();
        void runScan();
      }
      if (e.key === "Escape") setResult(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [runScan]);

  // auto-scan when a stable, well-lit face is held inside the reticle
  useEffect(() => {
    if (!autoScan || scanning) return;
    if (!faceLocked || quality < 0.45 || cooldown > 0) return;
    const id = window.setTimeout(() => void runScan(), 2200);
    return () => window.clearTimeout(id);
  }, [autoScan, scanning, faceLocked, quality, cooldown, runScan]);

  const verdict = useMemo(() => {
    if (!result) return null;
    return result.ok
      ? {
          tone: "go" as const,
          title: "Verified",
          sub: `${result.user?.name ?? "Identity matched"} · ${mode === "check_out" ? "checked out" : "attendance recorded"}`,
        }
      : {
          tone: "stop" as const,
          title: "No match",
          sub: result.reason ?? "Face not recognised",
        };
  }, [result, mode]);

  const recent = (feed.data?.logs ?? []).slice(0, 7);
  const clock = formatClock(now);

  return (
    <div className="space-y-5">
      <ToastStack toasts={toasts} dismiss={dismiss} />

      {/* ---------- command bar ---------- */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="reveal">
          <div className="flex items-center gap-2 font-mono text-[10.5px] uppercase tracking-[0.28em] text-scan-400">
            <span className="h-1.5 w-1.5 rounded-full bg-scan-400 blip" />
            terminal 01 · live verification
          </div>
          <h1 className="mt-2 font-display text-[clamp(2rem,5vw,3.4rem)] font-bold leading-[0.95] tracking-[-0.03em]">
            Facial recognition
            <br />
            <span className="text-bone-500">check-in</span>
          </h1>
        </div>
        <div className="reveal flex flex-wrap items-center gap-2">
          <div className="flex rounded-xl border border-[var(--hairline)] bg-ink-850/70 p-1">
            {(["check_in", "check_out"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-mono text-[10.5px] font-semibold uppercase tracking-[0.14em] transition-colors ${
                  mode === m ? "bg-bone-50 text-ink-900" : "text-bone-500 hover:text-bone-200"
                }`}
              >
                {m === "check_in" ? <IconEnter width={14} height={14} /> : <IconExit width={14} height={14} />}
                {m === "check_in" ? "check in" : "check out"}
              </button>
            ))}
          </div>
          <button
            onClick={() => setAutoScan((a) => !a)}
            className={`btn px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] ${autoScan ? "!border-go-400/50 !text-go-400" : ""}`}
            aria-pressed={autoScan}
          >
            <IconBolt width={13} height={13} />
            {autoScan ? "Auto-scan armed" : "Auto-scan off"}
          </button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.42fr)_minmax(0,0.58fr)]">
        {/* ---------- camera + CTA ---------- */}
        <div className="reveal space-y-3">
          <CameraStage
            handleRef={cam}
            variant="scan"
            scanning={scanning}
            autoStart
            verdict={scanning ? null : (result ? (result.ok ? "go" : "stop") : null)}
            onState={setCamState}
            onMetric={(m) => {
              setQuality(m?.quality?.overall ?? 0);
              setMotion(m?.motion ?? 0);
              setFaceLocked(Boolean(m?.hasFace) && (m?.quality?.size ?? 0) > 0.2);
            }}
          />

          {/* pipeline strip */}
          <Panel className="overflow-hidden">
            <div className="grid grid-cols-2 divide-[var(--hairline)] sm:grid-cols-4 sm:divide-x">
              {PHASES.map((p, i) => {
                const idx = PHASES.findIndex((x) => x.key === phase);
                const done = idx > i || phase === "done";
                const active = phase === p.key;
                return (
                  <div key={p.key} className={`px-3.5 py-3 transition-colors duration-300 ${active ? "bg-scan-400/[0.07]" : ""}`}>
                    <div className="flex items-center gap-2">
                      <span
                        className={`grid h-4 w-4 place-items-center rounded-full border font-mono text-[9px] ${
                          done ? "border-go-400 bg-go-400/15 text-go-400" : active ? "border-scan-400 text-scan-400" : "border-[var(--hairline-strong)] text-bone-600"
                        }`}
                      >
                        {done ? <IconCheck width={9} height={9} /> : i + 1}
                      </span>
                      <span className={`font-mono text-[10px] uppercase tracking-[0.16em] ${active ? "text-scan-300" : "text-bone-500"}`}>{p.label}</span>
                      {active ? <span className="ml-auto h-1 w-1 rounded-full bg-scan-400 blip" /> : null}
                    </div>
                    <p className="mt-1.5 hidden text-[11px] leading-snug text-bone-600 sm:block">{p.detail}</p>
                  </div>
                );
              })}
            </div>
          </Panel>

          {/* CTA */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-stretch">
            <button
              onClick={() => void runScan()}
              disabled={scanning || camState !== "live"}
              className={`btn flex-1 px-6 py-4 font-display text-[15px] font-bold uppercase tracking-[0.12em] ${
                mode === "check_in" ? "btn-primary" : "btn-amber"
              }`}
            >
              {scanning ? (
                <>
                  <span className="ring-spin inline-block h-4 w-4 rounded-full border-2 border-ink-950/30 border-t-ink-950" />
                  Scanning…
                </>
              ) : (
                <>
                  <IconShield width={17} height={17} />
                  Scan &amp; {mode === "check_in" ? "check in" : "check out"}
                  <kbd className="ml-2 hidden rounded border border-current/25 px-1.5 py-0.5 font-mono text-[10px] uppercase opacity-70 sm:inline">S</kbd>
                </>
              )}
            </button>
            <div className="flex w-full items-center gap-3 rounded-xl border border-[var(--hairline)] bg-ink-850/70 px-3.5 py-2.5 sm:w-[15.5rem]">
              <div className="flex-1">
                <div className="mb-1 flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-bone-500">
                  <span>signal</span>
                  <span className={quality > 0.5 ? "text-go-400" : "text-signal-400"}>{(quality * 100).toFixed(0)}%</span>
                </div>
                <Meter value={quality} tone={quality > 0.5 ? "#45d48c" : "#f5b942"} />
                <div className="mb-1 mt-2 flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.14em] text-bone-500">
                  <span>liveness</span>
                  <span className={motion > 0.06 ? "text-go-400" : "text-stop-400"}>{(motion * 100).toFixed(0)}%</span>
                </div>
                <Meter value={motion} tone={motion > 0.06 ? "#45d48c" : "#ff6b72"} />
              </div>
            </div>
          </div>
        </div>

        {/* ---------- verdict + feed rail ---------- */}
        <div className="space-y-4">
          <Panel corner className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-[var(--hairline)] px-4 py-2.5">
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-bone-500">verification result</span>
              <span className="font-mono text-[11px] tabular-nums text-bone-400">{clock}</span>
            </div>

            {!result ? (
              <div className="px-4 py-7 text-center">
                <div className={`mx-auto grid h-14 w-14 place-items-center rounded-2xl border transition-colors ${faceLocked ? "border-go-400/50 bg-go-400/10 text-go-400" : "border-[var(--hairline-strong)] text-bone-600"}`}>
                  {faceLocked ? <IconCheck width={24} height={24} /> : <IconUsers width={22} height={22} />}
                </div>
                <p className="mt-3 font-display text-[15px] font-bold">
                  {camState !== "live" ? "Sensor not streaming" : faceLocked ? "Face locked — ready" : "Searching for a face"}
                </p>
                <p className="mx-auto mt-1 max-w-[30ch] text-[12px] leading-relaxed text-bone-500">
                  {camState !== "live"
                    ? "Initialise the camera above, then press Scan."
                    : faceLocked
                      ? mode === "check_in"
                        ? "Hold still inside the reticle and press Scan & check in."
                        : "End-of-shift mode: a verified scan will close today's record."
                      : "Centre your face in the frame, remove sunglasses or heavy masks, keep the eyes level."}
                </p>
                {cooldown > 0 ? <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.18em] text-scan-400">next auto scan in {cooldown}s</p> : null}
              </div>
            ) : (
              <div className={`px-4 py-4 ${result.ok ? "" : "shake"}`}>
                <div className="flex items-center gap-3">
                  {result.ok && result.user ? (
                    <Avatar name={result.user.name} src={result.user.photoUrl} size={46} />
                  ) : (
                    <span className="grid h-[46px] w-[46px] place-items-center rounded-[10px] border border-stop-400/40 bg-stop-400/10 text-stop-400">
                      <IconWarn width={22} height={22} />
                    </span>
                  )}
                  <div className="min-w-0">
                    <div className={`font-display text-[19px] font-bold leading-tight ${result.ok ? "text-go-400" : "text-stop-400"}`}>{verdict?.title}</div>
                    <div className="truncate text-[12.5px] text-bone-400">{verdict?.sub}</div>
                  </div>
                  <button onClick={() => setResult(null)} className="btn ml-auto !h-7 !w-7 !rounded-lg !border-transparent !bg-transparent" aria-label="Dismiss result">
                    <IconClose width={13} height={13} />
                  </button>
                </div>

                {result.ok && result.user ? (
                  <div className="mt-3 grid grid-cols-2 gap-2 text-[11.5px]">
                    <Cell label="identity" value={result.user.name} />
                    <Cell label="role" value={result.user.role} />
                    <Cell label="time" value={formatClock(result.at)} />
                    <Cell label="status" value={<Pill status={result.status ?? "present"} />} />
                  </div>
                ) : (
                  <p className="mt-3 rounded-lg border border-stop-400/25 bg-stop-400/[0.07] px-3 py-2 text-[12px] leading-relaxed text-bone-200">{result.hint}</p>
                )}

                <div className="mt-3 space-y-2 rounded-lg border border-[var(--hairline)] bg-ink-950/50 p-3">
                  <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">
                    <span>correlation</span>
                    <span className={result.ok ? "text-go-400" : "text-stop-400"}>
                      {result.score?.toFixed(3) ?? "0.000"} / gate {result.threshold?.toFixed(2) ?? "0.72"}
                    </span>
                  </div>
                  <Meter value={(result.score ?? 0) / Math.max(0.001, result.threshold ?? 0.72) / 1.35} tone={result.ok ? "#45d48c" : "#ff6b72"} />
                  <div className="flex flex-wrap gap-x-4 gap-y-1 pt-1 font-mono text-[10px] uppercase tracking-[0.12em] text-bone-600">
                    <span>latency {result.latencyMs}ms</span>
                    <span>margin {result.margin?.toFixed(3) ?? "—"}</span>
                    <span>{result.offline ? "on-device verdict" : `${result.gallerySize ?? gallery} identities`}</span>
                    {result.duplicate ? <span className="text-signal-400">repeat scan</span> : null}
                  </div>
                </div>

                <div className="mt-3 flex gap-2">
                  <button className="btn flex-1 px-3 py-2 text-[11.5px] uppercase tracking-[0.1em]" onClick={() => void runScan()}>
                    Rescan
                  </button>
                  <Link href="/admin" className="btn flex-1 px-3 py-2 text-[11.5px] uppercase tracking-[0.1em]">
                    Ledger
                  </Link>
                </div>
              </div>
            )}
          </Panel>

          {/* live ticker */}
          <Panel>
            <PanelHead
              title="Live ledger"
              sub="Streaming from the verification service"
              icon={<IconClock width={15} height={15} />}
              right={
                <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-go-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-go-400 blip" /> live
                </span>
              }
            />
            <ul className="divide-y divide-[var(--hairline)]">
              {recent.length === 0 ? (
                <li className="px-4 py-6 text-center text-[12px] text-bone-500">No events yet today — be the first to scan.</li>
              ) : (
                recent.map((l, i) => (
                  <li key={l.id} className="row-in flex items-center gap-2.5 px-3.5 py-2.5" style={{ animationDelay: `${i * 45}ms` }}>
                    {l.photoUrl ? (
                      <Avatar name={l.name ?? "?"} src={l.photoUrl} size={26} />
                    ) : (
                      <span className="grid h-[26px] w-[26px] place-items-center rounded-md border border-[var(--hairline-strong)] font-mono text-[9px] text-bone-500">
                        {l.name ? initials(l.name) : "?"}
                      </span>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[12.5px] font-semibold">{l.name ?? "Unknown face"}</div>
                      <div className="font-mono text-[10px] uppercase tracking-[0.12em] text-bone-600">
                        {formatClock(l.timestamp)} · {l.eventType.replace("_", " ")}
                        {l.confidence ? ` · ${l.confidence.toFixed(2)}` : ""}
                      </div>
                    </div>
                    <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: statusMeta(l.status).dot }} />
                  </li>
                ))
              )}
            </ul>
            <div className="flex items-center justify-between gap-3 border-t border-[var(--hairline)] px-4 py-2.5">
              <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">
                present <span className="tabular-nums text-bone-50">{present.toFixed(0)}</span> / {feed.data?.roster.filter((r) => r.status === "active").length ?? 0}
              </span>
              {queued > 0 ? <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-signal-400">{queued} queued offline</span> : null}
              <Link href="/register" className="font-mono text-[10px] uppercase tracking-[0.14em] text-scan-400 underline-offset-4 hover:underline">
                enrol →
              </Link>
            </div>
          </Panel>

          {/* pipeline console */}
          <Panel className="hidden lg:block">
            <PanelHead title="Pipeline trace" sub="Last 8 engine events" icon={<IconBolt width={15} height={15} />} />
            <ul className="max-h-[184px] space-y-1 overflow-y-auto px-4 py-3 font-mono text-[10.5px] leading-relaxed">
              {log.length === 0 ? <li className="text-bone-600">awaiting first capture…</li> : null}
              {log.map((l) => (
                <li key={l.t + l.text} className="flex gap-2">
                  <span className="text-bone-600">{new Date(l.t).toLocaleTimeString("en-GB", { hour12: false })}</span>
                  <span className={l.tone === "go" ? "text-go-400" : l.tone === "stop" ? "text-stop-400" : "text-bone-300"}>{l.text}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>

      {/* ---------- floor status marquee ---------- */}
      <Panel className="overflow-hidden">
        <div className="flex items-center gap-3 border-l-2 border-scan-400/40 px-4 py-2.5">
          <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.2em] text-bone-500">floor status</span>
          <div className="relative flex-1 overflow-hidden">
            <div className="flex w-max gap-8 marquee">
              {[0, 1].map((dup) => (
                <div key={dup} className="flex gap-8">
                  {(feed.data?.roster ?? []).map((u) => (
                    <span key={u.id + dup} className="flex items-center gap-2 whitespace-nowrap text-[12px] text-bone-400">
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: statusMeta(u.todayStatus).dot }} />
                      <span className="font-semibold text-bone-200">{u.name}</span>
                      <span className="font-mono text-[10px] uppercase tracking-[0.12em] text-bone-600">
                        {u.todayCheckIn ? `in ${formatClock(u.todayCheckIn)}` : relativeTime(u.lastSeenAt ?? u.createdAt)}
                      </span>
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function Cell({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-[var(--hairline)] bg-ink-950/45 px-2.5 py-1.5">
      <div className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-bone-600">{label}</div>
      <div className="mt-0.5 truncate text-[12.5px] font-semibold text-bone-50">{value}</div>
    </div>
  );
}
