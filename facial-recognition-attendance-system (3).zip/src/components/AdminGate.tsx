"use client";

import { useCallback, useEffect, useState } from "react";
import { IconLock, IconShield } from "@/components/Icons";
import { authorize, signOut } from "@/lib/api";

export default function AdminGate({ children }: { children: (ctx: { lock: () => void }) => React.ReactNode }) {
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    fetch("/api/auth/admin", { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => alive && setAuthorized(Boolean(j.authorized)))
      .catch(() => alive && setAuthorized(false));
    return () => {
      alive = false;
    };
  }, []);

  const lock = useCallback(() => {
    void signOut().catch(() => undefined);
    setAuthorized(false);
  }, []);

  const submit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setBusy(true);
      setError(null);
      try {
        await authorize(passcode);
        setAuthorized(true);
        setPasscode("");
      } catch (err) {
        setError(err instanceof Error ? err.message : "Authorisation failed");
        setAuthorized(false);
      } finally {
        setBusy(false);
      }
    },
    [passcode],
  );

  if (authorized === null) {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <div className="flex flex-col items-center gap-3">
          <span className="ring-spin inline-block h-9 w-9 rounded-full border-2 border-scan-400/25 border-t-scan-400" />
          <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-bone-500">checking session…</p>
        </div>
      </div>
    );
  }

  if (authorized) return <>{children({ lock })}</>;

  return (
    <div className="mx-auto grid min-h-[62vh] max-w-[440px] place-items-center">
      <form onSubmit={submit} className={`panel panel-corner rise w-full rounded-2xl p-6 ${error ? "shake" : ""}`}>
        <span className="grid h-11 w-11 place-items-center rounded-xl border border-signal-400/40 bg-signal-400/10 text-signal-400">
          <IconLock width={20} height={20} />
        </span>
        <h1 className="mt-4 font-display text-[24px] font-bold leading-tight tracking-[-0.02em]">Administrator authorisation</h1>
        <p className="mt-1.5 text-[12.5px] leading-relaxed text-bone-400">
          The console can read every biometric template reference and write overrides to the attendance ledger. An HTTP-only session
          cookie is issued for 8 hours.
        </p>
        <label className="mt-5 block">
          <span className="mb-1.5 block font-mono text-[10px] uppercase tracking-[0.18em] text-bone-500">passcode</span>
          <input
            autoFocus
            type="password"
            className="field font-mono"
            placeholder="••••••••"
            value={passcode}
            onChange={(e) => setPasscode(e.target.value)}
          />
        </label>
        {error ? (
          <p className="mt-2 flex items-center gap-1.5 text-[12px] text-stop-400">
            <IconShield width={13} height={13} /> {error}
          </p>
        ) : (
          <p className="mt-2 font-mono text-[10.5px] uppercase tracking-[0.14em] text-bone-600">demo passcode · frs-admin</p>
        )}
        <button className="btn btn-primary mt-5 w-full px-4 py-2.5 text-[13px] uppercase tracking-[0.12em]" disabled={busy || passcode.length === 0}>
          {busy ? "Verifying…" : "Unlock console"}
        </button>
      </form>
    </div>
  );
}
