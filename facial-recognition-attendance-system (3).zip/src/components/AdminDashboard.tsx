"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  IconChart,
  IconCheck,
  IconClock,
  IconGrid,
  IconRefresh,
  IconSearch,
  IconShield,
  IconSliders,
  IconUsers,
  IconWarn,
} from "@/components/Icons";
import { Avatar, Empty, Meter, Panel, PanelHead, Pill, Stat, ToastStack } from "@/components/ui";
import { fetchFeed, markAttendance, resetDay, saveConfig, signOut, type FeedPayload } from "@/lib/api";
import { useCountUp, useLiveFeed, useReveal, useToasts } from "@/lib/hooks";
import { formatClock, formatHM, initials, relativeTime, statusMeta, type LogRecord } from "@/lib/shared";

/* ------------------------------- charts -------------------------------- */

function Donut({ value, label }: { value: number; label: string }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, value));
  return (
    <div className="relative grid h-[104px] w-[104px] shrink-0 place-items-center">
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="7" />
        <circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          stroke="url(#dg)"
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ transition: "stroke-dashoffset 900ms cubic-bezier(0.16,1,0.3,1)" }}
        />
        <defs>
          <linearGradient id="dg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#34e0c6" />
            <stop offset="100%" stopColor="#f5b942" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute text-center">
        <div className="font-display text-[19px] font-bold leading-none tabular-nums">{(pct * 100).toFixed(0)}%</div>
        <div className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-bone-500">{label}</div>
      </div>
    </div>
  );
}

function WeekChart({ week }: { week: FeedPayload["week"] }) {
  const max = Math.max(1, ...week.map((w) => w.present + w.late + w.absent));
  return (
    <div className="flex h-[168px] items-end gap-2 px-1">
      {week.map((w, i) => {
        const total = w.present + w.late + w.absent;
        const h = (n: number) => `${(n / max) * 100}%`;
        return (
          <div key={w.date} className="group relative flex flex-1 flex-col items-center gap-1.5 self-stretch">
            <div className="flex w-full flex-1 items-end gap-[3px] overflow-hidden rounded-md">
              <div className="flex w-full flex-col justify-end gap-[3px]">
                <div
                  className="w-full rounded-t-[3px] bg-stop-400/45 transition-all duration-700 group-hover:bg-stop-400/80"
                  style={{ height: h(w.absent) }}
                />
                <div className="w-full bg-caution-400/70 transition-all duration-700 group-hover:bg-caution-400" style={{ height: h(w.late) }} />
                <div
                  className="w-full rounded-b-[3px] bg-gradient-to-t from-scan-500 to-go-400 transition-all duration-700"
                  style={{ height: h(w.present) }}
                />
              </div>
            </div>
            <div className="font-mono text-[9.5px] uppercase tracking-[0.12em] text-bone-500 group-hover:text-bone-50">{w.label}</div>
            <div className="pointer-events-none absolute -top-1 left-1/2 z-10 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-md border border-[var(--hairline-strong)] bg-ink-950 px-2 py-1 font-mono text-[9.5px] uppercase tracking-wider opacity-0 shadow-xl transition-opacity duration-200 group-hover:opacity-100">
              {total} events · {w.present}p {w.late}l {w.absent}a
            </div>
            {i === week.length - 1 ? <span className="absolute -top-0.5 h-1 w-1 rounded-full bg-scan-400 blip" /> : null}
          </div>
        );
      })}
    </div>
  );
}

function HourlyArea({ hourly }: { hourly: FeedPayload["hourly"] }) {
  const W = 100;
  const H = 46;
  const max = Math.max(1, ...hourly.map((h) => h.count));
  const step = W / Math.max(1, hourly.length - 1);
  const pts = hourly.map((p, i) => [i * step, H - (p.count / max) * (H - 6) - 3] as const);
  const line = pts.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`).join(" ");
  const area = `${line} L${W},${H} L0,${H} Z`;
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="h-[68px] w-full">
        <defs>
          <linearGradient id="ha" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#34e0c6" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#34e0c6" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#ha)" />
        <path d={line} fill="none" stroke="#34e0c6" strokeWidth="1.1" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        {pts.map(([x, y], i) => (hourly[i]?.count ? <circle key={i} cx={x} cy={y} r="0.9" fill="#f5b942" /> : null))}
      </svg>
      <div className="mt-1 flex justify-between font-mono text-[9.5px] uppercase tracking-[0.12em] text-bone-600">
        <span>{String(hourly[0]?.hour ?? 6).padStart(2, "0")}:00</span>
        <span>peak {max}</span>
        <span>{String(hourly[hourly.length - 1]?.hour ?? 19).padStart(2, "0")}:00</span>
      </div>
    </div>
  );
}

/* ------------------------------- dashboard ------------------------------ */

const FILTERS = [
  { key: "all", label: "All" },
  { key: "check_in", label: "Check-ins" },
  { key: "check_out", label: "Check-outs" },
  { key: "denied", label: "Denied" },
  { key: "manual", label: "Overrides" },
];

export default function AdminDashboard({ onSignOut }: { onSignOut: () => void }) {
  const feed = useLiveFeed(() => fetchFeed(), { interval: 5000, channel: "frs-live" });
  const { toasts, push, dismiss } = useToasts();
  const [auto, setAuto] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [threshold, setThreshold] = useState<number | null>(null);
  const [cutoff, setCutoff] = useState("09:15");
  const [snapshots, setSnapshots] = useState(true);
  const [confirmReset, setConfirmReset] = useState<"today" | "all" | null>(null);
  const seen = useRef<Set<string>>(new Set());
  const [fresh, setFresh] = useState<Set<string>>(new Set());
  const data = feed.data;

  useReveal([data?.updatedAt]);

  useEffect(() => {
    if (!data) return;
    setThreshold((t) => (t === null ? data.config.matchThreshold : t));
    setCutoff(data.config.lateCutoff);
    setSnapshots(data.config.snapshots);
    const next = new Set<string>();
    data.logs.forEach((l) => {
      if (!seen.current.has(l.id)) {
        seen.current.add(l.id);
        if (Date.now() - new Date(l.timestamp).getTime() < 90000) next.add(l.id);
      }
    });
    if (next.size) setFresh(next);
  }, [data]);

  const t = data?.totals;
  const present = useCountUp(t?.present ?? 0);
  const absent = useCountUp(t?.absent ?? 0);
  const registered = useCountUp(t?.registered ?? 0);
  const denied = useCountUp(t?.denied ?? 0);

  const logs = useMemo(() => {
    const list = data?.logs ?? [];
    return list
      .filter((l) => (filter === "all" ? true : filter === "manual" ? l.method === "manual" : l.eventType === filter))
      .filter((l) => (query ? `${l.name ?? "unknown"} ${l.note ?? ""}`.toLowerCase().includes(query.toLowerCase()) : true));
  }, [data?.logs, filter, query]);

  if (!data) {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <div className="flex flex-col items-center gap-3">
          <span className="ring-spin inline-block h-10 w-10 rounded-full border-2 border-scan-400/25 border-t-scan-400" />
          <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-bone-500">aggregating attendance ledger…</p>
        </div>
      </div>
    );
  }

  const applyConfig = async () => {
    try {
      const next = await saveConfig({ matchThreshold: threshold ?? data.config.matchThreshold, lateCutoff: cutoff, snapshots });
      push("Gate updated", `Threshold ${next.matchThreshold.toFixed(2)} · late cutoff ${next.lateCutoff}`, "go");
      feed.broadcast();
      void feed.refresh();
    } catch (e) {
      push("Rejected", e instanceof Error ? e.message : "Unable to write config", "stop");
    }
  };

  const mark = async (userId: string, status: string, name: string) => {
    try {
      await markAttendance(userId, status);
      push("Override logged", `${name} · ${status}`, "signal");
      feed.broadcast();
      void feed.refresh();
    } catch (e) {
      push("Override failed", e instanceof Error ? e.message : "Service error", "stop");
    }
  };

  const exportCsv = () => {
    const rows = [
      ["timestamp", "member", "role", "event", "status", "confidence", "method", "note"],
      ...(data.logs.map((l) => [l.timestamp, l.name ?? "unknown", l.role ?? "-", l.eventType, l.status, String(l.confidence ?? ""), l.method, (l.note ?? "").replace(/,/g, ";")])),
    ];
    const blob = new Blob([rows.map((r) => r.join(",")).join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `frs-attendance-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    push("Export ready", `${data.logs.length} rows written to CSV`, "go");
  };

  return (
    <div className="space-y-5">
      <ToastStack toasts={toasts} dismiss={dismiss} />

      <div className="reveal flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 font-mono text-[10.5px] uppercase tracking-[0.28em] text-scan-400">
            <IconGrid width={13} height={13} /> admin console · read-write session
          </div>
          <h1 className="mt-2 font-display text-[clamp(1.9rem,4.4vw,3.1rem)] font-bold leading-[0.95] tracking-[-0.03em]">
            Attendance <span className="text-bone-500">operations</span>
          </h1>
          <p className="mt-2 text-[13px] text-bone-400">
            {new Date(data.date).toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long" })} · gate{" "}
            <span className="font-mono text-scan-400">{data.config.matchThreshold.toFixed(2)}</span> · late after{" "}
            <span className="font-mono text-signal-400">{data.config.lateCutoff}</span>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setAuto((a) => !a)}
            className={`btn px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.12em] ${auto ? "!border-go-400/45 !text-go-400" : ""}`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${auto ? "bg-go-400 blip" : "bg-bone-600"}`} />
            {auto ? `live · ${feed.updatedAt ? formatClock(feed.updatedAt) : "—"}` : "paused"}
          </button>
          <button className="btn px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.12em]" onClick={() => void feed.refresh()} disabled={feed.busy}>
            <IconRefresh width={13} height={13} className={feed.busy ? "ring-spin" : ""} /> Sync
          </button>
          <button className="btn px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.12em]" onClick={exportCsv}>
            Export CSV
          </button>
          <button
            className="btn px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.12em]"
            onClick={() => {
              void signOut();
              onSignOut();
            }}
          >
            <IconShield width={13} height={13} /> Lock
          </button>
        </div>
      </div>

      {/* ---------------- KPI rail ---------------- */}
      <div className="grid gap-3 lg:grid-cols-[minmax(0,1.25fr)_repeat(4,minmax(0,1fr))]">
        <Panel corner className="reveal flex items-center gap-4 p-4">
          <Donut value={t ? t.attendanceRate : 0} label="on site" />
          <div className="min-w-0">
            <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-scan-400">present now</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="font-display text-[46px] font-bold leading-none tabular-nums">{present.toFixed(0)}</span>
              <span className="font-mono text-[12px] text-bone-500">/ {data.roster.filter((r) => r.status === "active").length} active</span>
            </div>
            <p className="mt-2 text-[12px] leading-snug text-bone-400">
              {t && t.scans > 0 ? `${t.scans} biometric verifications today at a mean correlation of ${t.meanConfidence.toFixed(2)}.` : "No verifications recorded on this shift yet."}
            </p>
            <div className="mt-2">
              <Meter value={t ? t.attendanceRate : 0} tone="#45d48c" label={`late arrivals: ${t?.late ?? 0}`} />
            </div>
          </div>
        </Panel>

        <div className="reveal grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
          <Stat label="registered users" value={registered.toFixed(0)} hint={`${t?.enrolled ?? 0} with biometric templates`} tone="scan" />
          <Stat label="absent" value={absent.toFixed(0)} hint={`${t?.excused ?? 0} excused · ${t?.checkedOut ?? 0} checked out`} tone="muted" />
        </div>
        <div className="reveal grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
          <Stat label="late arrivals" value={t?.late ?? 0} hint={`cutoff ${data.config.lateCutoff}`} tone="caution" />
          <Stat label="denied scans" value={denied.toFixed(0)} hint="below gate or liveness trip" tone="stop" />
        </div>
        <div className="reveal panel rounded-2xl p-4">
          <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-bone-500">arrival curve</div>
          <div className="mt-2 text-[11.5px] text-bone-400">
            peak <span className="font-mono text-scan-400">{String(data.hourly.reduce((a, h) => (h.count > (data.hourly[a]?.count ?? 0) ? h.hour : data.hourly[a]?.hour ?? 6), 6)).padStart(2, "0")}:00</span>
          </div>
          <div className="mt-3">
            <HourlyArea hourly={data.hourly} />
          </div>
        </div>
        <div className="reveal panel rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-bone-500">top departments</div>
            <IconUsers width={14} height={14} className="text-bone-600" />
          </div>
          <ul className="mt-3 space-y-2.5">
            {Object.entries(
              data.roster.reduce<Record<string, { here: number; total: number }>>((acc, u) => {
                const b = acc[u.department] ?? { here: 0, total: 0 };
                b.total++;
                if (u.todayStatus === "present" || u.todayStatus === "late") b.here++;
                acc[u.department] = b;
                return acc;
              }, {}),
            )
              .sort((a, b) => b[1].total - a[1].total)
              .slice(0, 4)
              .map(([dept, v]) => (
                <li key={dept}>
                  <div className="flex items-center justify-between text-[11.5px]">
                    <span className="text-bone-200">{dept}</span>
                    <span className="font-mono text-bone-500">
                      {v.here}/{v.total}
                    </span>
                  </div>
                  <div className="mt-1">
                    <Meter value={v.total ? v.here / v.total : 0} tone={v.here ? "#34e0c6" : "#5d6b7a"} />
                  </div>
                </li>
              ))}
          </ul>
        </div>
      </div>

      {/* ---------------- charts + review ---------------- */}
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,0.7fr)]">
        <Panel className="reveal">
          <PanelHead
            title="Seven-day rollup"
            sub="check-ins, late arrivals and absences per day"
            icon={<IconChart width={15} height={15} />}
            right={
              <div className="flex items-center gap-3 font-mono text-[9.5px] uppercase tracking-[0.14em] text-bone-500">
                <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-go-400" /> present</span>
                <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-caution-400" /> late</span>
                <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-sm bg-stop-400/50" /> absent</span>
              </div>
            }
          />
          <div className="p-4">
            <WeekChart week={data.week} />
          </div>
        </Panel>

        <Panel className="reveal">
          <PanelHead title="Manual review queue" sub="unmatched captures held for triage" icon={<IconWarn width={15} height={15} />} />
          {data.review.length === 0 ? (
            <Empty text="No denied captures on this day. Every scan cleared the correlation gate." />
          ) : (
            <ul className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-3 xl:grid-cols-2">
              {data.review.slice(0, 6).map((l) => (
                <li key={l.id} className="group overflow-hidden rounded-lg border border-[var(--hairline)] bg-ink-950/50">
                  {l.snapshot ? (
                    <img src={l.snapshot} alt="review crop" className="aspect-square w-full object-cover opacity-80 transition-opacity group-hover:opacity-100" />
                  ) : (
                    <div className="grid aspect-square place-items-center text-bone-600">
                      <IconWarn width={22} height={22} />
                    </div>
                  )}
                  <div className="px-2 py-1.5 font-mono text-[9.5px] uppercase tracking-[0.1em] text-bone-500">
                    {formatHM(l.timestamp)} · {((l.confidence ?? 0) * 100).toFixed(0)}%
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      {/* ---------------- live log table ---------------- */}
      <Panel className="reveal">
        <PanelHead
          title="Live check-in ledger"
          sub={`${data.logs.length} events today · auto-refreshing`}
          icon={<IconClock width={15} height={15} />}
          right={
            <div className="flex items-center gap-2">
              <span className="relative">
                <IconSearch width={14} height={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-bone-600" />
                <input className="field !w-[9.5rem] !py-1 !pl-7 !text-[11.5px]" placeholder="filter" value={query} onChange={(e) => setQuery(e.target.value)} />
              </span>
            </div>
          }
        />
        <div className="flex flex-wrap gap-1 border-b border-[var(--hairline)] px-4 py-2">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`rounded-md px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.14em] transition-colors ${
                filter === f.key ? "bg-bone-50 text-ink-900" : "text-bone-500 hover:bg-white/[0.06] hover:text-bone-200"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] border-collapse text-left">
            <thead>
              <tr className="border-b border-[var(--hairline)] font-mono text-[9.5px] uppercase tracking-[0.18em] text-bone-500">
                <th className="px-4 py-2 font-semibold">time</th>
                <th className="px-4 py-2 font-semibold">member</th>
                <th className="px-4 py-2 font-semibold">event</th>
                <th className="px-4 py-2 font-semibold">status</th>
                <th className="px-4 py-2 font-semibold">confidence</th>
                <th className="px-4 py-2 font-semibold">source</th>
              </tr>
            </thead>
            <tbody>
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={6}>
                    <Empty text="No events match this filter yet." />
                  </td>
                </tr>
              ) : (
                logs.map((l, i) => <LogRowView key={l.id} log={l} fresh={fresh.has(l.id)} index={i} />)
              )}
            </tbody>
          </table>
        </div>
      </Panel>

      {/* ---------------- roster + settings ---------------- */}
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.45fr)_minmax(0,0.55fr)]">
        <Panel className="reveal">
          <PanelHead title="Personnel roster" sub="per-member status for today · manual overrides" icon={<IconUsers width={15} height={15} />} />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] border-collapse text-left">
              <thead>
                <tr className="border-b border-[var(--hairline)] font-mono text-[9.5px] uppercase tracking-[0.18em] text-bone-500">
                  <th className="px-4 py-2 font-semibold">member</th>
                  <th className="px-4 py-2 font-semibold">templates</th>
                  <th className="px-4 py-2 font-semibold">first scan</th>
                  <th className="px-4 py-2 font-semibold">today</th>
                  <th className="px-4 py-2 text-right font-semibold">override</th>
                </tr>
              </thead>
              <tbody>
                {data.roster.map((u, i) => (
                  <tr key={u.id} className="border-b border-[var(--hairline)]/60 transition-colors hover:bg-white/[0.03]" style={{ animationDelay: `${i * 25}ms` }}>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2.5">
                        {u.photoUrl ? <Avatar name={u.name} src={u.photoUrl} size={30} /> : <span className="grid h-[30px] w-[30px] place-items-center rounded-lg border border-[var(--hairline-strong)] font-mono text-[10px] text-bone-400">{initials(u.name)}</span>}
                        <div>
                          <div className="text-[13px] font-semibold">{u.name}</div>
                          <div className="font-mono text-[10px] uppercase tracking-[0.12em] text-bone-600">
                            {u.role} · {u.department}
                            {u.source === "seed" ? " · demo" : ""}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[11px] tabular-nums text-bone-200">{u.samples}</span>
                        <div className="w-14">
                          <Meter value={u.faceQuality} tone={u.faceQuality > 0.5 ? "#45d48c" : "#f5b942"} />
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-[11.5px] text-bone-300">
                      {u.todayCheckIn ? formatHM(u.todayCheckIn) : u.lastSeenAt ? relativeTime(u.lastSeenAt) : "—"}
                    </td>
                    <td className="px-4 py-2.5">
                      <Pill status={u.todayStatus} />
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex justify-end gap-1.5">
                        {(["present", "late", "excused", "absent"] as const).map((s) => (
                          <button
                            key={s}
                            onClick={() => void mark(u.id, s, u.name)}
                            className="btn !rounded-md !px-2 !py-1 font-mono !text-[9.5px] uppercase tracking-[0.1em]"
                            title={`Mark ${s}`}
                          >
                            {s === "present" ? <IconCheck width={11} height={11} /> : s.slice(0, 4)}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel className="reveal">
            <PanelHead title="Verifier gate" sub="applies to every future scan" icon={<IconSliders width={15} height={15} />} />
            <div className="space-y-4 p-4">
              <div>
                <div className="flex items-center justify-between text-[12px]">
                  <span className="font-semibold text-bone-200">Match threshold</span>
                  <span className="font-mono tabular-nums text-scan-400">{(threshold ?? data.config.matchThreshold).toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0.45}
                  max={0.96}
                  step={0.01}
                  value={threshold ?? data.config.matchThreshold}
                  onChange={(e) => setThreshold(Number(e.target.value))}
                  className="mt-2 w-full"
                />
                <p className="mt-1.5 text-[11px] leading-relaxed text-bone-500">
                  Lower accepts more variance (riskier impersonation), higher rejects more legitimately.
                  <span className="text-signal-400"> Current gallery mean correlation {((t?.meanConfidence ?? 0) * 100).toFixed(0)}%.</span>
                </p>
              </div>
              <label className="block">
                <span className="mb-1 block text-[12px] font-semibold text-bone-200">Late cutoff</span>
                <input type="time" className="field" value={cutoff} onChange={(e) => setCutoff(e.target.value)} />
              </label>
              <label className="flex cursor-pointer items-center gap-2.5 rounded-lg border border-[var(--hairline)] bg-ink-950/40 px-3 py-2.5">
                <input type="checkbox" checked={snapshots} onChange={(e) => setSnapshots(e.target.checked)} className="h-4 w-4 accent-[#34e0c6]" />
                <span className="text-[12px] text-bone-200">
                  Retain crops of denied faces
                  <span className="block text-[11px] text-bone-600">feeds the manual review queue above</span>
                </span>
              </label>
              <button className="btn btn-primary w-full px-3 py-2 text-[12px] uppercase tracking-[0.1em]" onClick={() => void applyConfig()}>
                Apply configuration
              </button>
            </div>
          </Panel>

          <Panel className="reveal">
            <PanelHead title="Housekeeping" sub="demo controls" icon={<IconWarn width={15} height={15} />} />
            <div className="space-y-2 p-4">
              {(["today", "all"] as const).map((scope) => (
                <button
                  key={scope}
                  className="btn btn-danger w-full px-3 py-2 text-[12px] uppercase tracking-[0.1em]"
                  onClick={() => {
                    if (confirmReset !== scope) {
                      setConfirmReset(scope);
                      return;
                    }
                    void resetDay(scope)
                      .then((r) => {
                        push("Reset complete", scope === "today" ? `${r.removed} rows cleared from today` : "gallery + ledger wiped", "signal");
                        seen.current = new Set();
                        feed.broadcast();
                        void feed.refresh();
                      })
                      .catch((e: unknown) => push("Reset failed", e instanceof Error ? e.message : "error", "stop"))
                      .finally(() => setConfirmReset(null));
                  }}
                >
                  {confirmReset === scope ? "Click again to confirm" : scope === "today" ? "Clear today's ledger" : "Wipe gallery + logs"}
                </button>
              ))}
              <p className="pt-1 text-[11px] leading-relaxed text-bone-600">
                Clearing today keeps the roster intact and re-seeds nothing — useful for running repeated check-in demos on the same
                device. <Link href="/register" className="text-scan-400 underline underline-offset-2">Enrolment station →</Link>
              </p>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function LogRowView({ log, fresh, index }: { log: LogRecord; fresh: boolean; index: number }) {
  return (
    <tr
      className={`border-b border-[var(--hairline)]/60 transition-colors hover:bg-white/[0.035] ${fresh ? "row-in" : ""}`}
      style={{ animationDelay: `${Math.min(index, 10) * 35}ms` }}
    >
      <td className="whitespace-nowrap px-4 py-2.5 font-mono text-[11.5px] tabular-nums text-bone-300">{formatClock(log.timestamp)}</td>
      <td className="px-4 py-2.5">
        <div className="flex items-center gap-2.5">
          {log.photoUrl ? <Avatar name={log.name ?? "?"} src={log.photoUrl} size={26} /> : <span className="grid h-[26px] w-[26px] place-items-center rounded-md border border-[var(--hairline-strong)] font-mono text-[9px] text-bone-500">{log.name ? initials(log.name) : "?"}</span>}
          <div className="min-w-0">
            <div className="truncate text-[12.5px] font-semibold">{log.name ?? "Unknown face"}</div>
            <div className="truncate font-mono text-[10px] uppercase tracking-[0.1em] text-bone-600">{log.role ?? "no identity bound"} {log.note ? ` · ${log.note}` : ""}</div>
          </div>
        </div>
      </td>
      <td className="px-4 py-2.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-bone-400">{log.eventType.replace("_", " ")}</td>
      <td className="px-4 py-2.5">
        <Pill status={log.status} />
      </td>
      <td className="px-4 py-2.5">
        {log.confidence ? (
          <div className="flex items-center gap-2">
            <div className="w-16">
              <Meter value={log.confidence} tone={statusMeta(log.status).dot} />
            </div>
            <span className="font-mono text-[11px] tabular-nums text-bone-300">{log.confidence.toFixed(3)}</span>
          </div>
        ) : (
          <span className="font-mono text-[11px] text-bone-600">manual</span>
        )}
      </td>
      <td className="px-4 py-2.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-bone-500">{log.method}</td>
    </tr>
  );
}
