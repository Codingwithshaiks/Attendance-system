"use client";

import Link from "next/link";
import { useCallback, useMemo, useRef, useState } from "react";
import CameraStage, { type CameraHandle } from "@/components/CameraStage";
import { IconAperture, IconCheck, IconClose, IconFace, IconShield, IconTrash, IconUsers, IconWarn } from "@/components/Icons";
import { Avatar, Meter, Panel, PanelHead, ToastStack } from "@/components/ui";
import { deleteUser, enrollUser, fetchRoster } from "@/lib/api";
import { useLiveFeed, useReveal, useToasts } from "@/lib/hooks";
import { DEPARTMENTS, ROLES, formatHM, initials, type Template } from "@/lib/shared";

interface Sample {
  id: number;
  template: Template;
  quality: number;
  patch: string;
}

const CHECKS: { key: "brightness" | "contrast" | "sharpness" | "size" | "centering"; label: string; advice: string }[] = [
  { key: "brightness", label: "Illumination", advice: "Light the face evenly — avoid strong backlight" },
  { key: "contrast", label: "Tonal range", advice: "Increase contrast: move away from flat wall lighting" },
  { key: "sharpness", label: "Focus", advice: "Hold still and clean the lens — the patch is soft" },
  { key: "size", label: "Face coverage", advice: "Step closer until the head fills the reticle" },
  { key: "centering", label: "Pose", advice: "Square up: keep the head centred and level" },
];

export default function EnrollmentStation() {
  const cam = useRef<CameraHandle | null>(null);
  const feed = useLiveFeed(() => fetchRoster({ templates: false }), { interval: 12000, channel: "frs-live" });
  const [samples, setSamples] = useState<Sample[]>([]);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState<{ name: string; warning: string | null } | null>(null);
  const [keepPhoto, setKeepPhoto] = useState(true);
  const [live, setLive] = useState({ overall: 0, brightness: 0, contrast: 0, sharpness: 0, size: 0, centering: 0 });
  const { toasts, push, dismiss } = useToasts();
  const [form, setForm] = useState({ name: "", role: "Employee" as string, email: "", department: "Operations" as string });

  useReveal([feed.updatedAt]);

  const roster = feed.data?.users ?? [];
  const enrolledCount = roster.filter((u) => u.source === "enrolled").length;

  const avgQuality = useMemo(() => (samples.length ? samples.reduce((a, s) => a + s.quality, 0) / samples.length : 0), [samples]);

  const capture = useCallback(async () => {
    if (samples.length >= 4) return;
    const cap = await cam.current?.capture();
    if (!cap) {
      push("Sensor idle", "Initialise the camera before capturing a reference.", "stop");
      return;
    }
    if (cap.quality.overall < 0.34) {
      push("Sample rejected", `Signal ${(cap.quality.overall * 100).toFixed(0)}% is below the 34% enrollment gate.`, "stop");
      return;
    }
    setSamples((s) => [...s, { id: Date.now(), template: cap.template, quality: cap.quality.overall, patch: cap.patch }]);
    push("Sample captured", `Quality ${(cap.quality.overall * 100).toFixed(0)}% · template +1`, "go");
  }, [push, samples.length]);

  const submit = useCallback(async () => {
    if (form.name.trim().length < 2) {
      push("Name required", "Enter the member's full legal name for the ledger.", "stop");
      return;
    }
    if (samples.length === 0) {
      push("No templates", "Capture at least one qualifying face sample.", "stop");
      return;
    }
    setBusy(true);
    try {
      const res = await enrollUser({
        name: form.name.trim(),
        role: form.role,
        email: form.email.trim() ? form.email.trim() : null,
        department: form.department,
        photoUrl: keepPhoto ? samples[samples.length - 1]!.patch : null,
        captures: samples.map((s) => ({ template: s.template, quality: s.quality })),
      });
      setSaved({ name: res.user.name, warning: res.warning });
      setSamples([]);
      setForm({ name: "", role: "Employee", email: "", department: "Operations" });
      feed.broadcast();
      void feed.refresh();
      push("Identity enrolled", `${res.user.name} · ${res.user.samples} templates in the gallery`, "go");
    } catch (e) {
      push("Enrollment blocked", e instanceof Error ? e.message : "Service error", "stop");
    } finally {
      setBusy(false);
    }
  }, [feed, form, keepPhoto, push, samples]);

  const remove = useCallback(
    async (id: string, name: string) => {
      try {
        await deleteUser(id);
        feed.broadcast();
        void feed.refresh();
        push("Template destroyed", `${name} removed from the gallery along with their ledger.`, "signal");
      } catch (e) {
        push("Delete failed", e instanceof Error ? e.message : "Admin authorisation required", "stop");
      }
    },
    [feed, push],
  );

  return (
    <div className="space-y-5">
      <ToastStack toasts={toasts} dismiss={dismiss} />

      <div className="reveal flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 font-mono text-[10.5px] uppercase tracking-[0.28em] text-signal-400">
            <IconAperture width={13} height={13} /> enrollment station · gallery writer
          </div>
          <h1 className="mt-2 font-display text-[clamp(1.9rem,4.4vw,3.1rem)] font-bold leading-[0.95] tracking-[-0.03em]">
            Register a face
            <span className="text-bone-500">.</span>
          </h1>
          <p className="mt-2 max-w-[62ch] text-[13.5px] leading-relaxed text-bone-400">
            Capture three neutral samples to build a redundant biometric template set. Frames never leave this device — only the
            768-dimensional descriptor is written to the gallery.
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-[var(--hairline)] bg-ink-850/70 px-3.5 py-2.5">
          <IconUsers width={16} height={16} className="text-scan-400" />
          <div>
            <div className="font-display text-[19px] font-bold leading-none tabular-nums">{roster.length}</div>
            <div className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-bone-500">{enrolledCount} device-enrolled</div>
          </div>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.82fr)]">
        {/* -------- form + capture -------- */}
        <div className="reveal space-y-4">
          <Panel>
            <PanelHead title="Identity record" sub="users table · id, name, role, photo_url" icon={<IconFace width={15} height={15} />} />
            <div className="grid gap-3 p-4 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className="mb-1 block font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">full name *</span>
                <input
                  className="field"
                  placeholder="e.g. Naomi Fitzgerald"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  maxLength={64}
                />
              </label>
              <label>
                <span className="mb-1 block font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">role</span>
                <select className="field" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                  {ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                <span className="mb-1 block font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">department</span>
                <select className="field" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}>
                  {DEPARTMENTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </label>
              <label className="sm:col-span-2">
                <span className="mb-1 block font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">email (optional)</span>
                <input
                  className="field"
                  placeholder="name@company.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  inputMode="email"
                  maxLength={120}
                />
              </label>
              <label className="flex cursor-pointer items-center gap-2.5 rounded-lg border border-[var(--hairline)] bg-ink-950/40 px-3 py-2.5 sm:col-span-2">
                <input
                  type="checkbox"
                  checked={keepPhoto}
                  onChange={(e) => setKeepPhoto(e.target.checked)}
                  className="h-4 w-4 accent-[#34e0c6]"
                />
                <span className="text-[12.5px] text-bone-200">
                  Save the reference crop to <code className="font-mono text-[11.5px] text-scan-400">users.photo_url</code>
                  <span className="ml-2 text-bone-600">(avatar only — turn off for strict privacy mode)</span>
                </span>
              </label>
            </div>
          </Panel>

          <CameraStage
            handleRef={cam}
            variant="enroll"
            samples={samples.length}
            autoStart
            onMetric={(m) => setLive({ ...(m?.quality ?? { overall: 0, brightness: 0, contrast: 0, sharpness: 0, size: 0, centering: 0 }) })}
          />

          <Panel>
            <PanelHead
              title="Reference samples"
              sub={`${samples.length}/3 recommended · max 4 · avg quality ${(avgQuality * 100).toFixed(0)}%`}
              icon={<IconShield width={15} height={15} />}
              right={
                <button
                  className="btn btn-amber px-3 py-1.5 text-[11.5px] uppercase tracking-[0.1em]"
                  onClick={() => void capture()}
                  disabled={samples.length >= 4}
                >
                  <IconAperture width={14} height={14} /> Capture sample
                </button>
              }
            />
            <div className="flex flex-wrap items-center gap-3 p-4">
              {samples.length === 0 ? (
                <p className="text-[12.5px] text-bone-500">
                  No samples yet. Frame your face inside the ellipse, wait for the quality bars to turn green, then capture.
                </p>
              ) : (
                samples.map((s, i) => (
                  <div key={s.id} className="group relative">
                    <img src={s.patch} alt={`sample ${i + 1}`} className="h-[74px] w-[74px] rounded-lg border border-[var(--hairline-strong)] object-cover" />
                    <span className="absolute -bottom-1.5 -left-1.5 rounded bg-ink-950 px-1 font-mono text-[9px] uppercase tracking-wider text-go-400">
                      {(s.quality * 100).toFixed(0)}
                    </span>
                    <button
                      onClick={() => setSamples((list) => list.filter((x) => x.id !== s.id))}
                      className="btn absolute -right-1.5 -top-1.5 !h-5 !w-5 !rounded-full !border-ink-950 !bg-ink-950 opacity-0 transition-opacity group-hover:opacity-100"
                      aria-label="Remove sample"
                    >
                      <IconClose width={10} height={10} />
                    </button>
                  </div>
                ))
              )}
              <div className="ml-auto flex flex-wrap gap-2">
                <button className="btn px-3.5 py-2 text-[12px] uppercase tracking-[0.1em]" onClick={() => setSamples([])} disabled={!samples.length}>
                  Clear
                </button>
                <button
                  className="btn btn-primary px-4 py-2 text-[12.5px] uppercase tracking-[0.1em]"
                  onClick={() => void submit()}
                  disabled={busy || !samples.length}
                >
                  {busy ? (
                    <>
                      <span className="ring-spin inline-block h-3.5 w-3.5 rounded-full border-2 border-ink-950/30 border-t-ink-950" /> Writing
                    </>
                  ) : (
                    <>
                      <IconCheck width={14} height={14} /> Commit to gallery
                    </>
                  )}
                </button>
              </div>
            </div>
            {saved ? (
              <div className="mx-4 mb-4 rounded-lg border border-go-400/30 bg-go-400/[0.07] px-3.5 py-3">
                <div className="flex items-center gap-2 font-display text-[13px] font-bold uppercase tracking-[0.1em] text-go-400">
                  <IconCheck width={15} height={15} /> {saved.name} is live in the gallery
                </div>
                <p className="mt-1 text-[12px] leading-relaxed text-bone-300">
                  Walk over to the{" "}
                  <Link href="/" className="text-scan-400 underline underline-offset-2">
                    check-in terminal
                  </Link>{" "}
                  and scan to verify.
                  {saved.warning ? <span className="mt-1 block text-caution-400">⚠ {saved.warning}</span> : null}
                </p>
              </div>
            ) : null}
          </Panel>
        </div>

        {/* -------- quality + roster -------- */}
        <div className="space-y-4">
          <Panel>
            <PanelHead title="Capture quality" sub="Live gating · all bars must clear 34%" icon={<IconWarn width={15} height={15} />} />
            <ul className="space-y-2.5 p-4">
              {CHECKS.map((c) => {
                const v = live[c.key] ?? 0;
                const ok = v >= 0.34;
                return (
                  <li key={c.key}>
                    <div className="flex items-center justify-between text-[11.5px]">
                      <span className="flex items-center gap-1.5">
                        <span className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-go-400" : "bg-signal-400"}`} />
                        <span className="font-semibold text-bone-200">{c.label}</span>
                      </span>
                      <span className={`font-mono tabular-nums ${ok ? "text-go-400" : "text-signal-400"}`}>{(v * 100).toFixed(0)}%</span>
                    </div>
                    <div className="mt-1">
                      <Meter value={v} tone={ok ? "#45d48c" : "#f5b942"} />
                    </div>
                    {!ok ? <p className="mt-1 text-[11px] text-bone-500">{c.advice}</p> : null}
                  </li>
                );
              })}
              <li className="!mt-3 flex items-center justify-between rounded-lg border border-[var(--hairline)] bg-ink-950/45 px-3 py-2">
                <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-bone-500">composite</span>
                <span className={`font-display text-[17px] font-bold tabular-nums ${live.overall >= 0.5 ? "text-go-400" : "text-signal-400"}`}>
                  {(live.overall * 100).toFixed(0)}%
                </span>
              </li>
            </ul>
          </Panel>

          <Panel>
            <PanelHead
              title="Biometric gallery"
              sub={`${roster.length} identities · ${roster.reduce((a, u) => a + u.samples, 0)} templates`}
              icon={<IconUsers width={15} height={15} />}
              right={
                <button className="btn px-2.5 py-1 text-[10.5px] uppercase tracking-[0.12em]" onClick={() => void feed.refresh()}>
                  refresh
                </button>
              }
            />
            <ul className="max-h-[420px] divide-y divide-[var(--hairline)] overflow-y-auto">
              {roster.length === 0 ? (
                <li className="px-4 py-8 text-center text-[12.5px] text-bone-500">Gallery empty — enroll the first identity above.</li>
              ) : (
                roster.map((u, i) => (
                  <li key={u.id} className="row-in flex items-center gap-3 px-3.5 py-2.5" style={{ animationDelay: `${i * 30}ms` }}>
                    {u.photoUrl ? <Avatar name={u.name} src={u.photoUrl} size={32} /> : <span className="grid h-8 w-8 place-items-center rounded-lg border border-[var(--hairline-strong)] font-mono text-[10px] text-bone-400">{initials(u.name)}</span>}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-[13px] font-semibold">{u.name}</span>
                        {u.source === "seed" ? (
                          <span className="rounded border border-[var(--hairline-strong)] px-1 font-mono text-[9px] uppercase tracking-wider text-bone-500">demo</span>
                        ) : null}
                      </div>
                      <div className="font-mono text-[10px] uppercase tracking-[0.12em] text-bone-600">
                        {u.role} · {u.samples} tpl · q{(u.faceQuality * 100).toFixed(0)}%
                        {u.lastSeenAt ? ` · seen ${formatHM(u.lastSeenAt)}` : ""}
                      </div>
                    </div>
                    <span
                      className="rounded-full border px-2 py-0.5 font-mono text-[9.5px] uppercase tracking-[0.12em]"
                      style={{
                        borderColor: u.status !== "active" ? "#ff6b7255" : u.samples > 0 ? "#45d48c55" : "#f5b94255",
                        color: u.status !== "active" ? "#ff6b72" : u.samples > 0 ? "#45d48c" : "#f5b942",
                      }}
                    >
                      {u.status !== "active" ? "suspended" : u.samples > 0 ? "in gallery" : "no tpl"}
                    </span>
                    <button className="btn !h-7 !w-7 !rounded-lg" onClick={() => void remove(u.id, u.name)} aria-label={`Remove ${u.name}`}>
                      <IconTrash width={13} height={13} />
                    </button>
                  </li>
                ))
              )}
            </ul>
            <p className="border-t border-[var(--hairline)] px-4 py-2.5 text-[11px] leading-relaxed text-bone-600">
              Demo identities carry synthetic templates on purpose: a live scan will score below the gate and land in the admin review
              queue, which is exactly how an unenrolled face behaves.
            </p>
          </Panel>
        </div>
      </div>
    </div>
  );
}
