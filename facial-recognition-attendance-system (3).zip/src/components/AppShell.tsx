"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { IconAperture, IconCamera, IconChip, IconShield } from "@/components/Icons";
import { useNow } from "@/lib/hooks";

const NAV = [
  { href: "/", label: "Check-in", icon: IconCamera, note: "kiosk" },
  { href: "/register", label: "Enroll", icon: IconAperture, note: "roster" },
  { href: "/admin", label: "Console", icon: IconShield, note: "admin" },
];

function Led({ ok, label, value }: { ok: boolean | null; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 rounded-full border border-[var(--hairline)] bg-white/[0.03] px-2.5 py-1">
      <span
        className={`h-1.5 w-1.5 rounded-full ${ok === null ? "bg-bone-500" : ok ? "bg-go-400 blip" : "bg-stop-400"}`}
        style={{ boxShadow: ok ? "0 0 8px 1px currentColor" : undefined }}
      />
      <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-bone-500">{label}</span>
      <span className="font-mono text-[10px] text-bone-200">{value}</span>
    </div>
  );
}

export default function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const now = useNow(1000);
  const [health, setHealth] = useState<{ db: boolean; engine: string } | null>(null);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    let alive = true;
    const ping = async () => {
      try {
        const r = await fetch("/api/health", { cache: "no-store" });
        const j = await r.json();
        if (alive) setHealth({ db: Boolean(j.ok), engine: j.engine ?? "drizzle/pg" });
      } catch {
        if (alive) setHealth({ db: false, engine: "offline" });
      }
    };
    void ping();
    const id = window.setInterval(ping, 20000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const clock = new Date(now).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const day = new Date(now).toLocaleDateString("en-US", { weekday: "long", day: "2-digit", month: "short" });

  return (
    <div className="relative min-h-screen">
      <div className="ambient" aria-hidden>
        <div className="ambient-radar" />
        <div className="ambient-glow" />
        <div className="ambient-grid" />
        <div className="ambient-scanlines" />
        <div className="ambient-noise" />
      </div>

      <header
        className={`sticky top-0 z-40 border-b transition-all duration-300 ${
          scrolled ? "border-[var(--hairline)] bg-ink-950/85 backdrop-blur-xl" : "border-transparent bg-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 w-full max-w-[1500px] items-center gap-4 px-4 sm:px-6">
          <Link href="/" className="group flex items-center gap-3">
            <span className="relative grid h-9 w-9 place-items-center rounded-[10px] border border-scan-400/40 bg-scan-400/10 text-scan-400 transition-transform duration-500 group-hover:rotate-90">
              <IconAperture width={18} height={18} />
              <span className="absolute inset-0 rounded-[10px] ring-1 ring-inset ring-white/5" />
            </span>
            <span className="leading-tight">
              <span className="block font-display text-[15px] font-bold tracking-[-0.01em]">
                FRS<span className="text-scan-400">·</span>ATTEST
              </span>
              <span className="block font-mono text-[9.5px] uppercase tracking-[0.24em] text-bone-500">biometric attendance grid</span>
            </span>
          </Link>

          <nav className="ml-auto flex items-center gap-1 rounded-full border border-[var(--hairline)] bg-white/[0.03] p-1">
            {NAV.map((item) => {
              const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`group relative flex items-center gap-2 rounded-full px-3 py-1.5 text-[12.5px] font-semibold transition-colors duration-200 ${
                    active ? "bg-bone-50 text-ink-900" : "text-bone-400 hover:bg-white/[0.06] hover:text-bone-50"
                  }`}
                >
                  <Icon width={15} height={15} />
                  <span className="hidden sm:inline">{item.label}</span>
                  <span className={`font-mono text-[9px] uppercase tracking-widest ${active ? "text-ink-600" : "text-bone-600"} hidden md:inline`}>
                    {item.note}
                  </span>
                </Link>
              );
            })}
          </nav>

          <div className="hidden items-center gap-2 lg:flex">
            <Led ok={health?.db ?? null} label="db" value={health?.db ? "connected" : "probe"} />
            <Led ok label="engine" value={health?.engine ?? "hog-512"} />
          </div>

          <div className="hidden text-right md:block">
            <div className="font-mono text-[13px] tabular-nums text-bone-50">{clock}</div>
            <div className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-bone-500">{day}</div>
          </div>
        </div>
      </header>

      <main className="relative z-10 mx-auto w-full max-w-[1500px] px-4 pb-16 pt-5 sm:px-6">{children}</main>

      <footer className="relative z-10 border-t border-[var(--hairline)] bg-ink-950/60">
        <div className="mx-auto flex w-full max-w-[1500px] flex-wrap items-center gap-x-6 gap-y-2 px-4 py-5 text-[11.5px] text-bone-500 sm:px-6">
          <span className="flex items-center gap-2 font-mono uppercase tracking-[0.18em]">
            <IconChip width={14} height={14} className="text-scan-500" /> template 512-d hog + 256-d high-pass residual
          </span>
          <span className="flex items-center gap-2 font-mono uppercase tracking-[0.18em]">
            <IconShield width={14} height={14} className="text-signal-400" /> enrolled frames never leave the device
          </span>
          <span className="ml-auto font-mono text-bone-600">FRS build 2.4.1 · {new Date(now).getFullYear()}</span>
        </div>
      </footer>
    </div>
  );
}
