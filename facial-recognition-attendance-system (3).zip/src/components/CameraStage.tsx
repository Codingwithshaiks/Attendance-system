"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createAnalyzer, detectFaceNative, extractFromSource, snapshot, type Analyzer, type FaceBox } from "@/lib/face";
import { IconCamera, IconClose, IconRefresh, IconShield, IconWarn } from "@/components/Icons";
import { Meter } from "@/components/ui";
import type { FrameMetric, QualityReport, Template } from "@/lib/shared";
import { readLS, writeLS, lsKeys } from "@/lib/api";

export type CamState = "idle" | "requesting" | "live" | "denied" | "missing" | "unsupported" | "error";

export interface CaptureResult {
  template: Template;
  quality: QualityReport;
  patch: string;
  review: string | null;
  motion: number;
  box: FaceBox;
  detector: string;
  resolution: string;
}

export interface CameraHandle {
  capture: () => Promise<CaptureResult | null>;
  metric: () => FrameMetric | null;
  state: () => CamState;
}

interface Props {
  handleRef: React.MutableRefObject<CameraHandle | null>;
  onMetric?: (m: FrameMetric | null) => void;
  onState?: (s: CamState) => void;
  scanning?: boolean;
  autoStart?: boolean;
  variant?: "scan" | "enroll";
  samples?: number;
  verdict?: "go" | "stop" | null;
  hudExtra?: React.ReactNode;
}

const STATE_COPY: Record<CamState, { title: string; body: string }> = {
  idle: { title: "Sensor offline", body: "Initialise the optical sensor to begin biometric verification." },
  requesting: { title: "Awaiting permission", body: "Grant camera access in the browser prompt to stream the sensor." },
  live: { title: "", body: "" },
  denied: { title: "Access denied", body: "Camera permission was blocked. Enable it in the address-bar site settings, then retry." },
  missing: { title: "No sensor found", body: "No camera device is attached. Connect a webcam or use a device with a front camera." },
  unsupported: { title: "Insecure context", body: "MediaDevices requires HTTPS or localhost. Serve this page over a secure origin." },
  error: { title: "Sensor fault", body: "The capture pipeline reported an error. Retry or select another device." },
};

export default function CameraStage({
  handleRef,
  onMetric,
  onState,
  scanning = false,
  autoStart = false,
  variant = "scan",
  samples = 0,
  verdict = null,
  hudExtra,
}: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const analyzerRef = useRef<Analyzer | null>(null);
  const rafRef = useRef<number | null>(null);
  const metricRef = useRef<FrameMetric | null>(null);
  const smoothRef = useRef<FaceBox | null>(null);
  const nativeRef = useRef<FaceBox | null>(null);
  const onMetricRef = useRef(onMetric);
  onMetricRef.current = onMetric;

  const [state, setState] = useState<CamState>("idle");
  const [mirror, setMirror] = useState(() => readLS<boolean>(lsKeys.mirror, true));
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [activeDevice, setActiveDevice] = useState<string>(() => readLS<string>(lsKeys.device, ""));
  const [res, setRes] = useState({ w: 0, h: 0 });
  const [shutter, setShutter] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  const setCamState = useCallback(
    (s: CamState) => {
      setState(s);
      onState?.(s);
    },
    [onState],
  );

  const stop = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    const v = videoRef.current;
    if (v) v.srcObject = null;
  }, []);

  const start = useCallback(
    async (deviceId?: string) => {
      if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
        setCamState("unsupported");
        return;
      }
      setCamState("requesting");
      stop();
      const constraints: MediaStreamConstraints = {
        audio: false,
        video: {
          ...(deviceId ? { deviceId: { exact: deviceId } } : { facingMode: "user" }),
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 30 },
        },
      };
      try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        streamRef.current = stream;
        const v = videoRef.current;
        if (!v) return;
        v.srcObject = stream;
        v.muted = true;
        await v.play().catch(() => undefined);
        const track = stream.getVideoTracks()[0];
        const settings = track?.getSettings?.() as { deviceId?: string } | undefined;
        if (settings?.deviceId) {
          setActiveDevice(settings.deviceId);
          writeLS(lsKeys.device, settings.deviceId);
        }
        setRes({ w: v.videoWidth, h: v.videoHeight });
        setCamState("live");
        try {
          const all = await navigator.mediaDevices.enumerateDevices();
          setDevices(all.filter((d) => d.kind === "videoinput"));
        } catch {
          /* ignore */
        }
      } catch (e) {
        const name = e instanceof DOMException ? e.name : "";
        if (name === "NotAllowedError" || name === "SecurityError") setCamState("denied");
        else if (name === "NotFoundError" || name === "OverconstrainedError") setCamState("missing");
        else setCamState("error");
      }
    },
    [setCamState, stop],
  );

  // ---- live analysis loop -------------------------------------------------
  useEffect(() => {
    if (state !== "live") return;
    analyzerRef.current = analyzerRef.current ?? createAnalyzer();
    let mounted = true;
    let lastRun = 0;
    let lastNative = 0;
    let t0 = performance.now();
    setElapsed(0);

    const loop = async (t: number) => {
      if (!mounted) return;
      rafRef.current = requestAnimationFrame(loop);
      if (t - lastRun < 90) return;
      lastRun = t;
      setElapsed(Math.floor((t - t0) / 1000));
      const v = videoRef.current;
      if (!v || v.readyState < 2) return;

      if (t - lastNative > 1400) {
        lastNative = t;
        void detectFaceNative(v).then((b) => {
          if (b) nativeRef.current = b;
        });
      }

      const m = analyzerRef.current!.measure(v, nativeRef.current);
      const prev = smoothRef.current;
      smoothRef.current = prev
        ? {
            x: prev.x + (m.box.x - prev.x) * 0.35,
            y: prev.y + (m.box.y - prev.y) * 0.35,
            w: prev.w + (m.box.w - prev.w) * 0.35,
            h: prev.h + (m.box.h - prev.h) * 0.35,
          }
        : { ...m.box };
      const metric = { ...m, box: smoothRef.current };
      metricRef.current = metric;
      onMetricRef.current?.(metric);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      mounted = false;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [state]);

  // ---- imperative API ----------------------------------------------------
  useEffect(() => {
    handleRef.current = {
      capture: async () => {
        const v = videoRef.current;
        if (!v || state !== "live") return null;
        setShutter(true);
        window.setTimeout(() => setShutter(false), 130);
        const box = smoothRef.current ?? metricRef.current?.box ?? { x: 0.26, y: 0.12, w: 0.48, h: 0.7 };
        const ex = extractFromSource(v, box);
        if (!ex) return null;
        return {
          template: ex.template,
          quality: ex.quality,
          patch: ex.patchDataUrl,
          review: snapshot(v, box),
          motion: metricRef.current?.motion ?? 0,
          box,
          detector: metricRef.current?.detector ?? "heuristic",
          resolution: `${res.w}x${res.h}`,
        };
      },
      metric: () => metricRef.current,
      state: () => state,
    };
  }, [handleRef, state, res.w, res.h]);

  useEffect(() => {
    if (autoStart) void start();
    return () => {
      stop();
      handleRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => writeLS(lsKeys.mirror, mirror), [mirror]);

  const metric = metricRef.current;
  const q = metric?.quality;
  const copy = STATE_COPY[state];
  const box = metric?.box ?? { x: 0.28, y: 0.13, w: 0.44, h: 0.66 };
  const dispX = mirror ? 1 - box.x - box.w : box.x;

  return (
    <div className="relative overflow-hidden rounded-2xl border border-[var(--hairline)] bg-ink-950">
      <div className="relative aspect-[4/3] w-full sm:aspect-[16/10]">
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className="absolute inset-0 h-full w-full object-cover"
          style={{ transform: mirror ? "scaleX(-1)" : undefined, filter: "contrast(1.03) saturate(0.94)" }}
        />

        {/* darkening vignette + viewfinder grid */}
        <div className="pointer-events-none absolute inset-0 viewfinder-grid opacity-40" />
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 88% at 50% 45%, transparent 42%, rgba(5,8,12,0.82) 100%)" }} />

        {/* face reticle */}
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          className="pointer-events-none absolute inset-0 h-full w-full"
          aria-hidden
        >
          <g style={{ transform: "translateZ(0)" }}>
            <rect
              x={dispX * 100}
              y={box.y * 100}
              width={box.w * 100}
              height={box.h * 100}
              fill="none"
              stroke={scanning ? "#34e0c6" : q && q.overall > 0.45 ? "#45d48c" : "rgba(214,211,203,0.55)"}
              strokeWidth={0.5}
              strokeDasharray={scanning ? "3 2" : "0"}
              rx={3}
              vectorEffect="non-scaling-stroke"
              className={scanning ? "" : "reticle-pulse"}
            />
            {/* corner brackets */}
            {[
              [dispX, box.y, 1, 1],
              [dispX + box.w, box.y, -1, 1],
              [dispX, box.y + box.h, 1, -1],
              [dispX + box.w, box.y + box.h, -1, -1],
            ].map(([px, py, sx, sy], i) => (
              <path
                key={i}
                d={`M${px * 100 + sx * 4} ${py * 100} L${px * 100} ${py * 100} L${px * 100} ${py * 100 + sy * 5}`}
                fill="none"
                stroke="#f5b942"
                strokeWidth={1.4}
                vectorEffect="non-scaling-stroke"
                strokeLinecap="round"
              />
            ))}
            {variant === "enroll" ? (
              <ellipse
                cx={(dispX + box.w / 2) * 100}
                cy={(box.y + box.h / 2) * 100}
                rx={box.w * 33}
                ry={box.h * 42}
                fill="none"
                stroke="rgba(52,224,198,0.5)"
                strokeWidth={0.4}
                strokeDasharray="1.6 1.6"
                vectorEffect="non-scaling-stroke"
              />
            ) : null}
          </g>
        </svg>

        {scanning ? <div className="scan-sweep" /> : null}

        {shutter ? <div className="pointer-events-none absolute inset-0 bg-bone-50/45" /> : null}
        {verdict === "go" ? <div className="pointer-events-none absolute inset-0 flash-go" /> : null}
        {verdict === "stop" ? <div className="pointer-events-none absolute inset-0 flash-stop" /> : null}

        {/* HUD: top row */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-2.5 sm:p-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="flex items-center gap-1.5 rounded-md bg-ink-950/70 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-bone-200 backdrop-blur">
              <span className={`h-1.5 w-1.5 rounded-full ${state === "live" ? "bg-stop-400 blip" : "bg-bone-600"}`} />
              {state === "live" ? `live ${res.w}x${res.h} · ${metric?.fps ?? 0}fps` : "sensor idle"}
            </span>
            <span className="hidden rounded-md bg-ink-950/70 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-scan-300 backdrop-blur sm:inline">
              lock: {metric?.detector ?? "none"}
            </span>
            <span className="hidden rounded-md bg-ink-950/70 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-bone-400 backdrop-blur md:inline">
              t+{String(Math.floor(elapsed / 60)).padStart(2, "0")}:{String(elapsed % 60).padStart(2, "0")}
            </span>
          </div>
          <div className="rounded-md bg-ink-950/70 px-2 py-1 text-right font-mono text-[10px] uppercase tracking-[0.16em] backdrop-blur"
            style={{ color: q && q.overall > 0.55 ? "#45d48c" : "#f5b942" }}
          >
            sig {(q ? q.overall * 100 : 0).toFixed(0)}%
          </div>
        </div>

        {/* HUD: bottom row */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-2.5 sm:p-3">
          <div className="w-[46%] max-w-[190px] space-y-1 rounded-lg bg-ink-950/70 p-2 backdrop-blur">
            {(
              [
                ["light", q?.brightness ?? 0, "#f5b942"],
                ["range", q?.contrast ?? 0, "#34e0c6"],
                ["focus", q?.sharpness ?? 0, "#45d48c"],
              ] as const
            ).map(([label, value, tone]) => (
              <div key={label} className="flex items-center gap-2">
                <span className="w-9 font-mono text-[9px] uppercase tracking-[0.14em] text-bone-500">{label}</span>
                <Meter value={value} tone={tone} />
              </div>
            ))}
            <div className="flex items-center gap-2">
              <span className="w-9 font-mono text-[9px] uppercase tracking-[0.14em] text-bone-500">motion</span>
              <Meter value={metric?.motion ?? 0} tone={metric && metric.motion > 0.08 ? "#45d48c" : "#ff6b72"} />
            </div>
          </div>
          {hudExtra ? <div className="flex-1" /> : null}
          <div className="rounded-md bg-ink-950/70 px-2 py-1 text-right font-mono text-[10px] uppercase tracking-[0.14em] text-bone-400 backdrop-blur">
            {variant === "enroll" ? `sample ${samples}/3` : "liveness: passive"}
          </div>
        </div>

        {/* non-live overlays */}
        {state !== "live" ? (
          <div className="absolute inset-0 grid place-items-center bg-ink-950/88 px-6 text-center backdrop-blur-sm">
            {state === "requesting" ? (
              <div className="flex flex-col items-center gap-3">
                <span className="ring-spin inline-block h-9 w-9 rounded-full border-2 border-scan-400/25 border-t-scan-400" />
                <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-bone-400">negotiating sensor…</p>
              </div>
            ) : (
              <div className="flex max-w-[34ch] flex-col items-center gap-3">
                <span className={`grid h-11 w-11 place-items-center rounded-xl border ${state === "idle" ? "border-scan-400/40 text-scan-400" : "border-caution-400/40 text-caution-400"}`}>
                  {state === "idle" ? <IconCamera /> : <IconWarn />}
                </span>
                <h3 className="font-display text-[17px] font-bold">{copy.title}</h3>
                <p className="text-[12.5px] leading-relaxed text-bone-400">{copy.body}</p>
                <button className="btn btn-primary mt-1 px-4 py-2 text-[13px]" onClick={() => void start(activeDevice || undefined)}>
                  <IconRefresh width={15} height={15} />
                  {state === "idle" ? "Initialise camera" : "Retry sensor"}
                </button>
                <p className="mt-1 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-bone-600">
                  <IconShield width={12} height={12} /> frames are processed on-device
                </p>
              </div>
            )}
          </div>
        ) : null}
      </div>

      {/* control bar */}
      <div className="flex flex-wrap items-center gap-2 border-t border-[var(--hairline)] bg-ink-850/70 px-3 py-2">
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-bone-500">source</span>
        {devices.length > 1 ? (
          <select
            className="field !w-auto !py-1 !text-[11.5px]"
            value={activeDevice}
            onChange={(e) => {
              setActiveDevice(e.target.value);
              writeLS(lsKeys.device, e.target.value);
              void start(e.target.value);
            }}
          >
            {devices.map((d, i) => (
              <option key={d.deviceId} value={d.deviceId}>
                {d.label || `Camera ${i + 1}`}
              </option>
            ))}
          </select>
        ) : (
          <span className="font-mono text-[11px] text-bone-200">{devices[0]?.label || (state === "live" ? "default video input" : "none detected")}</span>
        )}

        <div className="ml-auto flex items-center gap-1.5">
          <button className="btn px-2.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.1em]" onClick={() => setMirror((m) => !m)}>
            {mirror ? "Mirrored" : "Unmirrored"}
          </button>
          {state === "live" ? (
            <button className="btn px-2.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.1em]" onClick={() => { stop(); setCamState("idle"); }} aria-label="Stop sensor">
              <IconClose width={13} height={13} /> Stop
            </button>
          ) : (
            <button className="btn px-2.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.1em]" onClick={() => void start(activeDevice || undefined)}>
              <IconCamera width={13} height={13} /> Start
            </button>
          )}
        </div>
      </div>

    </div>
  );
}
