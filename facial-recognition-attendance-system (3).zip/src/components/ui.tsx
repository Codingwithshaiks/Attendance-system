"use client";

import type { CSSProperties, ReactNode } from "react";
import { initials, statusMeta, toneText } from "@/lib/shared";

const TOAST_TONE: Record<string, string> = {
  go: "#45d48c",
  stop: "#ff6b72",
  signal: "#f5b942",
  scan: "#34e0c6",
};
import type { Toast } from "@/lib/hooks";
import { IconClose } from "@/components/Icons";

export function Panel({
  children,
  className = "",
  corner = false,
}: {
  children: ReactNode;
  className?: string;
  corner?: boolean;
}) {
  return <section className={`panel rounded-2xl ${corner ? "panel-corner" : ""} ${className}`}>{children}</section>;
}

export function PanelHead({
  title,
  sub,
  icon,
  right,
}: {
  title: string;
  sub?: string;
  icon?: ReactNode;
  right?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-[var(--hairline)] px-4 py-3 sm:px-5">
      <div className="flex items-center gap-2.5">
        {icon ? <span className="text-scan-400">{icon}</span> : null}
        <div>
          <h2 className="font-display text-[13.5px] font-bold uppercase tracking-[0.12em] text-bone-50">{title}</h2>
          {sub ? <p className="mt-0.5 text-[11.5px] text-bone-500">{sub}</p> : null}
        </div>
      </div>
      {right}
    </div>
  );
}

export function Pill({ status, extra = "" }: { status: string | null | undefined; extra?: string }) {
  const meta = statusMeta(status);
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.12em] ${extra}`}
      style={{ borderColor: `${meta.dot}55`, color: meta.dot, background: `${meta.dot}12` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.dot }} />
      {meta.label}
    </span>
  );
}

export function Meter({ value, tone = "#34e0c6", label }: { value: number; tone?: string; label?: string }) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div className="w-full">
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
        <div
          className="h-full rounded-full transition-[width] duration-700 ease-out"
          style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${tone}66, ${tone})`, boxShadow: `0 0 12px ${tone}80` }}
        />
      </div>
      {label ? <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.14em] text-bone-500">{label}</div> : null}
    </div>
  );
}

export function Avatar({ name, src, size = 36 }: { name: string; src?: string | null; size?: number }) {
  const style = { width: size, height: size };
  if (src) {
    return (
      <img
        src={src}
        alt={name}
        style={style}
        className="shrink-0 rounded-[10px] border border-[var(--hairline-strong)] object-cover"
        loading="lazy"
      />
    );
  }
  return (
    <span
      style={style}
      className="grid shrink-0 place-items-center rounded-[10px] border border-[var(--hairline-strong)] bg-gradient-to-br from-ink-600 to-ink-800 font-display text-[12px] font-bold text-bone-200"
    >
      {initials(name)}
    </span>
  );
}

export function Stat({
  label,
  value,
  unit,
  hint,
  tone = "scan",
  children,
}: {
  label: string;
  value: ReactNode;
  unit?: string;
  hint?: ReactNode;
  tone?: "scan" | "go" | "stop" | "signal" | "muted" | "caution";
  children?: ReactNode;
}) {
  return (
    <div className="group relative flex-1 overflow-hidden rounded-2xl border border-[var(--hairline)] bg-ink-850/70 p-4 transition-colors duration-300 hover:border-[var(--hairline-strong)]">
      <div
        className="pointer-events-none absolute -right-10 -top-12 h-28 w-28 rounded-full opacity-25 blur-2xl transition-opacity duration-500 group-hover:opacity-50"
        style={{ background: "currentColor" }}
      />
      <div className={`relative text-[10px] font-semibold uppercase tracking-[0.18em] ${toneText[tone]}`}>{label}</div>
      <div className="relative mt-2 flex items-baseline gap-1">
        <span className="font-display text-[30px] font-bold leading-none tabular-nums text-bone-50">{value}</span>
        {unit ? <span className="font-mono text-[11px] text-bone-500">{unit}</span> : null}
      </div>
      {hint ? <div className="relative mt-2 text-[11.5px] text-bone-500">{hint}</div> : null}
      {children}
    </div>
  );
}

/** Tiny SVG sparkline with animated draw. */
export function Sparkline({ points, tone = "#34e0c6", height = 34 }: { points: number[]; tone?: string; height?: number }) {
  if (points.length < 2) return <div style={{ height }} />;
  const max = Math.max(...points, 1);
  const min = Math.min(...points, 0);
  const span = max - min || 1;
  const w = 100;
  const step = w / (points.length - 1);
  const coords = points.map((p, i) => [i * step, height - ((p - min) / span) * (height - 6) - 3] as const);
  const d = coords.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`).join(" ");
  const area = `${d} L${w},${height} L0,${height} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none" className="w-full" style={{ height }} aria-hidden>
      <defs>
        <linearGradient id={`sp-${tone.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={tone} stopOpacity="0.35" />
          <stop offset="100%" stopColor={tone} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#sp-${tone.slice(1)})`} />
      <path d={d} fill="none" stroke={tone} strokeWidth="1.4" strokeLinecap="round" className="dash-draw" style={{ strokeDasharray: 260 } as CSSProperties} />
      <circle cx={coords[coords.length - 1]![0]} cy={coords[coords.length - 1]![1]} r="1.8" fill={tone} />
    </svg>
  );
}

export function ToastStack({ toasts, dismiss }: { toasts: Toast[]; dismiss: (id: number) => void }) {
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(24rem,calc(100vw-2rem))] flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="panel rise pointer-events-auto flex items-start gap-3 rounded-xl px-3.5 py-3"
          style={{ borderColor: `${statusMeta(t.tone).dot}44` }}
        >
          <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: statusMeta(t.tone).dot, boxShadow: `0 0 10px ${statusMeta(t.tone).dot}` }} />
          <div className="min-w-0 flex-1">
            <div className="font-display text-[12.5px] font-bold uppercase tracking-[0.1em]">{t.title}</div>
            {t.body ? <div className="mt-0.5 text-[12px] leading-snug text-bone-400">{t.body}</div> : null}
          </div>
          <button onClick={() => dismiss(t.id)} className="btn !h-6 !w-6 !rounded-md !border-transparent !bg-transparent !p-0 text-bone-500 hover:!text-bone-50" aria-label="Dismiss">
            <IconClose width={13} height={13} />
          </button>
        </div>
      ))}
    </div>
  );
}

export function Empty({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center gap-2 px-4 py-10 text-center">
      <div className="h-8 w-8 rounded-full border border-dashed border-bone-600" />
      <p className="max-w-[36ch] text-[12.5px] text-bone-500">{text}</p>
    </div>
  );
}
