import EnrollmentStation from "@/components/EnrollmentStation";

export default function RegisterPage() {
  return <EnrollmentStation />;
}
