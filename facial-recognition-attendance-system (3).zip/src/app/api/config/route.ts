import { DEFAULT_CONFIG, ensureSeeded, getConfig, requireAdmin, saveConfig } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  return Response.json(await getConfig());
}

export async function PATCH(req: Request) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const next = await saveConfig(body);
    return Response.json(next);
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Config rejected", config: DEFAULT_CONFIG }, { status: 400 });
  }
}
