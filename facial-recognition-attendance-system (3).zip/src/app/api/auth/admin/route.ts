import { cookies } from "next/headers";
import { COOKIE, adminToken, isAdmin } from "@/lib/server";

export const dynamic = "force-dynamic";

const MAX_AGE = 60 * 60 * 8;

export async function GET(req: Request) {
  return Response.json({ authorized: await isAdmin(req) });
}

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { passcode?: string };
  const expected = process.env.ADMIN_PASSCODE ?? "frs-admin";
  const given = (body.passcode ?? "").trim();
  const ok = given.length > 0 && given === expected;
  if (!ok) {
    return Response.json({ ok: false, error: "Passcode rejected" }, { status: 401 });
  }
  const jar = await cookies();
  jar.set(COOKIE, adminToken(), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE,
    secure: process.env.NODE_ENV === "production",
  });
  return Response.json({ ok: true, session: { scope: "read-write", expiresIn: MAX_AGE } });
}

export async function DELETE() {
  const jar = await cookies();
  jar.set(COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return Response.json({ ok: true });
}
