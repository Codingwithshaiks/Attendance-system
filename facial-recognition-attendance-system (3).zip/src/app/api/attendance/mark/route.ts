import { eq } from "drizzle-orm";
import { db } from "@/db";
import { attendanceLogs, users } from "@/db/schema";
import { ensureSeeded, isAdmin, mapLog } from "@/lib/server";

export const dynamic = "force-dynamic";

/** Admin override: mark a member present / late / excused / absent by hand. */
export async function POST(req: Request) {
  const denied = await isAdmin(req);
  if (!denied) return Response.json({ error: "Administrator authorisation required" }, { status: 401 });

  try {
    await ensureSeeded();
    const body = (await req.json()) as { userId?: string; status?: string; note?: string };
    const status = body.status ?? "present";
    if (!["present", "late", "excused", "absent", "checked_out"].includes(status)) {
      return Response.json({ error: "Unsupported status" }, { status: 400 });
    }
    if (!body.userId) return Response.json({ error: "userId is required" }, { status: 400 });

    const [user] = await db.select().from(users).where(eq(users.id, body.userId)).limit(1);
    if (!user) return Response.json({ error: "Unknown member" }, { status: 404 });

    const [log] = await db
      .insert(attendanceLogs)
      .values({
        userId: user.id,
        timestamp: new Date(),
        status,
        eventType: status === "checked_out" ? "check_out" : "manual",
        method: "manual",
        note: (body.note ?? "Manual override by administrator").slice(0, 200),
        device: "admin-console",
      })
      .returning();

    return Response.json({ ok: true, log: mapLog({ ...log, name: user.name, role: user.role, photoUrl: user.photoUrl }) }, { status: 201 });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Override failed" }, { status: 500 });
  }
}


