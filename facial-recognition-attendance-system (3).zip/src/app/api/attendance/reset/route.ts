import { requireAdmin, wipeDay, ensureSeeded } from "@/lib/server";

export const dynamic = "force-dynamic";

/** Operator housekeeping: clear today's ledger (or the whole store) for demos. */
export async function POST(req: Request) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  await ensureSeeded();
  const body = (await req.json().catch(() => ({}))) as { scope?: string };
  const scope = body.scope === "all" ? "all" : "today";
  try {
    const result = await wipeDay(scope);
    return Response.json({ ok: true, scope, ...result });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Reset failed" }, { status: 500 });
  }
}
