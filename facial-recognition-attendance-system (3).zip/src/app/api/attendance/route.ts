import { buildFeed } from "@/lib/server";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return Response.json(await buildFeed());
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Feed unavailable" }, { status: 500 });
  }
}
