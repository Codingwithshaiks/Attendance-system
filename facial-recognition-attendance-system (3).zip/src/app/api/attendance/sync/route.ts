import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { attendanceLogs } from "@/db/schema";
import { ensureSeeded } from "@/lib/server";

export const dynamic = "force-dynamic";

/**
 * Receives logs queued by the kiosk while the network was down.
 * Idempotent on (user_id, timestamp) so a retried flush never double-books.
 */
export async function POST(req: Request) {
  await ensureSeeded();
  const body = (await req.json().catch(() => ({}))) as {
    logs?: {
      user_id?: string;
      timestamp?: string;
      status?: string;
      event_type?: string;
      confidence?: number;
    }[];
  };
  const incoming = (body.logs ?? []).slice(0, 200);
  if (incoming.length === 0) return Response.json({ synced: 0 });

  let synced = 0;
  for (const l of incoming) {
    if (!l.user_id || !l.timestamp) continue;
    const ts = new Date(l.timestamp);
    if (Number.isNaN(ts.getTime())) continue;
    const [existing] = await db
      .select({ id: attendanceLogs.id })
      .from(attendanceLogs)
      .where(and(eq(attendanceLogs.userId, l.user_id), eq(attendanceLogs.timestamp, ts)))
      .limit(1);
    if (existing) continue;
    await db.insert(attendanceLogs).values({
      userId: l.user_id,
      timestamp: ts,
      status: l.status === "checked_out" ? "checked_out" : "present",
      eventType: l.event_type === "check_out" ? "check_out" : "check_in",
      method: "offline",
      confidence: typeof l.confidence === "number" ? Number(l.confidence.toFixed(4)) : null,
      liveness: null,
      note: "Replayed from kiosk offline queue",
      device: "offline-queue",
    });
    synced++;
  }
  return Response.json({ synced });
}


