import { db } from "@/db";
import { sql } from "drizzle-orm";
import { DEFAULT_CONFIG } from "@/lib/server";
import { FACE_CANVAS, HOG_DIM, TEXTURE_DIM } from "@/lib/shared";

export const dynamic = "force-dynamic";

export async function GET() {
  let rows: number | string = "n/a";
  let database = "unreachable";
  try {
    const result = await db.execute(sql`select current_database() as db`);
    database = (result.rows as { db: string }[])[0]?.db ?? "app_db";
    const counted = await db.execute(sql`select count(*)::int as users from "users"`);
    rows = (counted.rows as { users: number }[])[0]?.users ?? 0;
  } catch {
    /* the pipeline may not be migrated yet — health stays green as long as pg answers */
  }

  try {
    await db.execute(sql`select 1`);
    return Response.json({
      ok: true,
      service: "frs-attest",
      engine: `hog-${HOG_DIM}+hp-${TEXTURE_DIM}@${FACE_CANVAS}px`,
      database,
      rows,
      threshold: DEFAULT_CONFIG.matchThreshold,
      time: new Date().toISOString(),
    });
  } catch {
    return Response.json({ ok: false, service: "frs-attest", engine: "unavailable" }, { status: 500 });
  }
}
