import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { attendanceLogs, users } from "@/db/schema";
import { ensureSeeded, getConfig, mapLog, mapUser } from "@/lib/server";
import { similarity } from "@/lib/face";
import { isLate, type Template } from "@/lib/shared";

export const dynamic = "force-dynamic";

interface CheckInBody {
  template?: Template;
  event?: "check_in" | "check_out";
  quality?: number;
  liveness?: number;
  snapshot?: string | null;
  device?: string;
}

const MIN_DIM = 128;

export async function POST(req: Request) {
  const started = Date.now();
  try {
    await ensureSeeded();
    const body = (await req.json()) as CheckInBody;
    const hog = body.template?.hog;
    const texture = body.template?.texture;
    if (!Array.isArray(hog) || hog.length < MIN_DIM || !Array.isArray(texture) || texture.length < 64) {
      return Response.json({ error: "Malformed facial template" }, { status: 400 });
    }
    const probe: Template = { hog, texture };
    const event = body.event === "check_out" ? "check_out" : "check_in";
    const quality = Number.isFinite(body.quality) ? Number(body.quality) : 0;
    const liveness = Number.isFinite(body.liveness) ? Number(body.liveness) : 0;
    const config = await getConfig();
    const now = new Date();

    const gallery = await db
      .select()
      .from(users)
      .where(eq(users.status, "active"))
      .orderBy(desc(users.lastSeenAt));

    const ranked = gallery
      .filter((u) => (u.samples ?? 0) > 0)
      .map((u) => {
        const templates = (u.embeddings ?? []) as Template[];
        let score = 0;
        let hits = 0;
        for (const t of templates) {
          const s = similarity(t, probe);
          if (s > score) score = s;
          if (s > 0.3) hits++;
        }
        return { user: u, score, hits };
      })
      .filter((r) => r.hits > 0)
      .sort((a, b) => b.score - a.score);

    const best = ranked[0];
    const runnerUp = ranked[1];
    const margin = best && runnerUp ? best.score - runnerUp.score : 1;
    const qualityOk = quality >= 0.28;
    const livenessOk = liveness >= 0.05;
    const matched = Boolean(best && best.score >= config.matchThreshold && margin >= config.margin && qualityOk && livenessOk);
    const device = (body.device ?? "kiosk").slice(0, 40);

    if (best && matched) {
      const user = best.user;
      let status: string = "present";
      if (event === "check_out") status = "checked_out";
      else status = isLate(now, config.lateCutoff) ? "late" : "present";

      const prior = await db
        .select({ id: attendanceLogs.id, timestamp: attendanceLogs.timestamp, status: attendanceLogs.status })
        .from(attendanceLogs)
        .where(eq(attendanceLogs.userId, user.id))
        .orderBy(desc(attendanceLogs.timestamp))
        .limit(4);
      const dayStart = new Date(now);
      dayStart.setHours(0, 0, 0, 0);
      const duplicate = event === "check_in" && prior.some((p) => new Date(p.timestamp) >= dayStart && p.status !== "checked_out");

      const [log] = await db
        .insert(attendanceLogs)
        .values({
          userId: user.id,
          timestamp: now,
          status,
          eventType: event,
          method: "face",
          confidence: Number(best.score.toFixed(4)),
          liveness: Number(liveness.toFixed(3)),
          note: duplicate
            ? "Repeat scan within the same attendance day"
            : `1:N gallery scan · ${gallery.length} identities · ${user.samples} template${user.samples === 1 ? "" : "s"}`,
          device,
        })
        .returning();

      await db.update(users).set({ lastSeenAt: now }).where(eq(users.id, user.id));

      const [fresh] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);

      return Response.json({
        ok: true,
        score: Number(best.score.toFixed(4)),
        threshold: config.matchThreshold,
        margin: Number(margin.toFixed(4)),
        latencyMs: Date.now() - started,
        status,
        duplicate,
        gallerySize: gallery.length,
        user: mapUser(fresh ?? user),
        log: log ? mapLog({ ...log, name: user.name, role: user.role, photoUrl: user.photoUrl }) : null,
      });
    }

    const reason = !qualityOk
      ? "Signal quality too low"
      : !livenessOk
        ? "Liveness guard triggered"
        : !best
          ? "No face lock acquired"
          : best.score < config.matchThreshold
            ? "Face not recognised"
            : "Identity margin below tolerance";

    const hint = !qualityOk
      ? "Increase ambient light and hold still — the descriptor needs contrast."
      : !livenessOk
        ? "Static frame detected. Blink and move naturally, or cover the lens to re-arm."
        : !best
          ? "Centre your face inside the reticle and retry."
          : best.score < config.matchThreshold
            ? `Best correlation ${best.score.toFixed(2)} against a ${config.matchThreshold.toFixed(2)} threshold. Enrol the face or lower the threshold.`
            : `Runner-up gap ${margin.toFixed(3)} is too small. Capture another sample to sharpen the template.`;

    const [log] = await db
      .insert(attendanceLogs)
      .values({
        userId: null,
        timestamp: now,
        status: "denied",
        eventType: event === "check_out" ? "check_out" : "denied",
        method: "face",
        confidence: best ? Number(best.score.toFixed(4)) : 0,
        liveness: Number(liveness.toFixed(3)),
        snapshot: config.snapshots && typeof body.snapshot === "string" && body.snapshot.startsWith("data:image") ? body.snapshot : null,
        note: `${reason} · ${hint}`,
        device,
      })
      .returning();

    return Response.json({
      ok: false,
      reason,
      hint,
      score: best ? Number(best.score.toFixed(4)) : 0,
      threshold: config.matchThreshold,
      margin: Number(margin.toFixed(4)),
      latencyMs: Date.now() - started,
      gallerySize: gallery.length,
      log: log ? mapLog({ ...log, name: null, role: null, photoUrl: null }) : null,
    });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Verification service error" }, { status: 500 });
  }
}
