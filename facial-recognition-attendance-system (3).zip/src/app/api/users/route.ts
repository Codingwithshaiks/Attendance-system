import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { attendanceLogs, users } from "@/db/schema";
import { DEFAULT_CONFIG, ensureSeeded, getConfig, mapUser } from "@/lib/server";
import { similarity } from "@/lib/face";
import type { Template } from "@/lib/shared";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const url = new URL(req.url);
  const withTemplates = url.searchParams.get("templates") === "1";
  const rows = await db.select().from(users).orderBy(desc(users.createdAt));
  const config = withTemplates ? await getConfig() : DEFAULT_CONFIG;
  // Templates ship to the kiosk on request so it can keep matching faces when the
  // network drops — the raw enrollment frames never do.
  return Response.json({
    users: rows.map((r) => mapUser(r, { withTemplates })),
    config,
  });
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const body = (await req.json()) as {
      name?: string;
      role?: string;
      email?: string | null;
      department?: string;
      photoUrl?: string | null;
      captures?: { template: Template; quality?: number }[];
    };

    const name = (body.name ?? "").trim().replace(/\s+/g, " ");
    if (name.length < 2 || name.length > 64) {
      return Response.json({ error: "Name must be 2–64 characters" }, { status: 400 });
    }
    const captures = (body.captures ?? []).filter(
      (c) => Array.isArray(c?.template?.hog) && c.template.hog.length >= 128 && Array.isArray(c?.template?.texture),
    );
    if (captures.length === 0) {
      return Response.json({ error: "At least one valid facial template is required" }, { status: 422 });
    }

    const config = await getConfig();
    const existing = await db.select().from(users).where(eq(users.status, "active"));

    // collision guard — refuse to enrol a face that already exists in the gallery
    for (const u of existing) {
      const templates = (u.embeddings ?? []) as Template[];
      let max = 0;
      for (const c of captures) for (const t of templates) max = Math.max(max, similarity(t, c.template));
      if (max > 0.9) {
        return Response.json({
          error: `${name} looks identical to the enrolled template for ${u.name} (similarity ${max.toFixed(2)})`,
          duplicateOf: u.name,
        }, { status: 409 });
      }
    }

    let distinct = 0;
    for (const u of existing) {
      for (const t of (u.embeddings ?? []) as Template[]) {
        for (const c of captures) distinct = Math.max(distinct, similarity(t, c.template));
      }
    }

    const intra = captures.length > 1 ? (() => {
      let acc = 0;
      let n = 0;
      for (let i = 0; i < captures.length; i++)
        for (let j = i + 1; j < captures.length; j++) {
          acc += similarity(captures[i]!.template, captures[j]!.template);
          n++;
        }
      return n ? acc / n : 1;
    })() : 0.5;

    const quality = captures.reduce((a, c) => a + (c.quality ?? 0), 0) / captures.length;

    const [row] = await db
      .insert(users)
      .values({
        name,
        role: (body.role ?? "Employee").slice(0, 32),
        email: body.email?.trim() ? body.email.trim().slice(0, 120) : null,
        department: (body.department ?? "Operations").slice(0, 40),
        photoUrl: typeof body.photoUrl === "string" && body.photoUrl.startsWith("data:image") ? body.photoUrl : null,
        embeddings: captures.map((c) => c.template),
        samples: captures.length,
        faceQuality: Number(quality.toFixed(3)),
        distinctiveness: Number((1 - distinct).toFixed(3)),
        source: "enrolled",
        status: "active",
      })
      .returning();

    await db.insert(attendanceLogs).values({
      userId: row!.id,
      status: "present",
      eventType: "manual",
      method: "manual",
      confidence: null,
      note: `Enrolled · ${captures.length} template${captures.length > 1 ? "s" : ""}, quality ${(quality * 100).toFixed(0)}%`,
      device: "enrollment-station",
    });

    const warning =
      intra < config.matchThreshold
        ? "Intra-sample consistency is below the match threshold. Re-capture in steadier lighting for a more stable template."
        : null;

    return Response.json({ user: mapUser(row!), warning, duplicateOf: null }, { status: 201 });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Enrollment failed" }, { status: 500 });
  }
}


