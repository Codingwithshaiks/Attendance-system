import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureSeeded, mapUser, requireAdmin } from "@/lib/server";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  await ensureSeeded();
  const { id } = await ctx.params;
  const [row] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!row) return Response.json({ error: "Member not found" }, { status: 404 });
  return Response.json({ user: mapUser(row) });
}

/** Suspend / reactivate an identity without destroying its biometric template. */
export async function PATCH(req: Request, ctx: Ctx) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  const body = (await req.json()) as { status?: string };
  const status = body.status === "suspended" ? "suspended" : "active";
  const [row] = await db.update(users).set({ status }).where(eq(users.id, id)).returning();
  if (!row) return Response.json({ error: "Member not found" }, { status: 404 });
  return Response.json({ user: mapUser(row) });
}

/** Right to erasure: removes the member and cascades their attendance ledger. */
export async function DELETE(req: Request, ctx: Ctx) {
  const denied = await requireAdmin(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  const [row] = await db.delete(users).where(eq(users.id, id)).returning({ id: users.id });
  if (!row) return Response.json({ error: "Member not found" }, { status: 404 });
  return Response.json({ ok: true, id: row.id });
}
