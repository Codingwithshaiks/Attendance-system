import FacialCheckIn from "@/components/FacialCheckIn";

export default function CheckInPage() {
  return <FacialCheckIn />;
}
