import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import AppShell from "@/components/AppShell";

export const metadata: Metadata = {
  title: "FRS · Facial Recognition Attendance Terminal",
  description:
    "Biometric attendance kiosk with live facial embedding verification, offline queueing and a real-time admin analytics console.",
};

export const viewport: Viewport = {
  themeColor: "#080c12",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans text-bone-50">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
