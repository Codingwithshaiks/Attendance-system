"use client";

import AdminGate from "@/components/AdminGate";
import AdminDashboard from "@/components/AdminDashboard";

export default function AdminPage() {
  return <AdminGate>{({ lock }) => <AdminDashboard onSignOut={lock} />}</AdminGate>;
}
