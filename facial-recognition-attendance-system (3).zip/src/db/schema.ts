import { doublePrecision, index, integer, jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

/**
 * FRS Attendance — persistence layer.
 *
 * Privacy model: enrolled staff are represented by biometric templates
 * (HOG + high-pass texture descriptors). Raw frames are only persisted for
 * the manual review queue of *unrecognized* faces and for the enrollment
 * avatar the operator explicitly saves.
 */
export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: text("name").notNull(),
    role: text("role").notNull().default("Employee"),
    email: text("email"),
    department: text("department").notNull().default("Operations"),
    photoUrl: text("photo_url"),
    /** number[][] — one template per captured enrollment sample */
    embeddings: jsonb("embeddings").notNull().default([]),
    samples: integer("samples").notNull().default(0),
    faceQuality: doublePrecision("face_quality").notNull().default(0),
    distinctiveness: doublePrecision("distinctiveness").notNull().default(0),
    status: text("status").notNull().default("active"),
    source: text("source").notNull().default("enrolled"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("users_name_idx").on(t.name), index("users_status_idx").on(t.status)],
);

export const attendanceLogs = pgTable(
  "attendance_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
    timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
    /** present | late | checked_out | excused | absent | denied */
    status: text("status").notNull().default("present"),
    /** check_in | check_out | denied | manual */
    eventType: text("event_type").notNull().default("check_in"),
    /** face | manual | offline | seed */
    method: text("method").notNull().default("face"),
    confidence: doublePrecision("confidence"),
    liveness: doublePrecision("liveness"),
    snapshot: text("snapshot"),
    note: text("note"),
    device: text("device"),
  },
  (t) => [index("logs_ts_idx").on(t.timestamp), index("logs_user_idx").on(t.userId), index("logs_status_idx").on(t.status)],
);

export const systemConfig = pgTable("system_config", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type UserRow = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type LogRow = typeof attendanceLogs.$inferSelect;
export type ConfigRow = typeof systemConfig.$inferSelect;
