"use client";

import type { LogRecord, Template, UserRecord } from "./shared";
import { scoreTemplates } from "./face";

const LS = {
  device: "frs.camera.device",
  mirror: "frs.camera.mirror",
  autoScan: "frs.kiosk.autoscan",
  roster: "frs.cache.roster",
  logs: "frs.cache.logs",
  lastResult: "frs.kiosk.lastResult",
  queue: "frs.queue.logs",
  passcode: "frs.admin.authorized",
};

export function readLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeLS(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota / private mode — non fatal */
  }
}

export const lsKeys = LS;

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    cache: "no-store",
    credentials: "same-origin",
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  });
  const text = await res.text();
  const body = text ? (JSON.parse(text) as unknown) : null;
  if (!res.ok) {
    const msg = body && typeof body === "object" && "error" in body ? String((body as { error?: string }).error) : `${res.status} ${res.statusText}`;
    throw new ApiError(msg, res.status);
  }
  return body as T;
}

/* ------------------------------- roster ---------------------------------- */

export async function fetchRoster(opts: { templates?: boolean } = {}) {
  const data = await request<{ users: UserRecord[]; config: SystemConfig }>(
    `/api/users${opts.templates ? "?templates=1" : ""}`,
  );
  writeLS(LS.roster, data.users);
  writeLS(LS.mirror + ".config", data.config);
  return data;
}

export function cachedRoster(): UserRecord[] {
  return readLS<UserRecord[]>(LS.roster, []);
}

export async function enrollUser(payload: {
  name: string;
  role: string;
  email: string | null;
  department: string;
  photoUrl: string | null;
  captures: { template: Template; quality: number }[];
}) {
  return request<{ user: UserRecord; warning: string | null; duplicateOf: string | null }>(`/api/enroll`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function deleteUser(id: string) {
  return request<{ ok: boolean }>(`/api/users/${id}`, { method: "DELETE" });
}

/* ------------------------------- verification ----------------------------- */

export interface CheckInResponse {
  ok: boolean;
  offline?: boolean;
  score: number;
  threshold: number;
  margin: number;
  latencyMs: number;
  user?: UserRecord;
  log?: LogRecord;
  reason?: string;
  hint?: string;
  duplicate?: boolean;
  status?: string;
  gallerySize?: number;
}

export async function checkIn(payload: {
  template: Template;
  event: "check_in" | "check_out";
  quality: number;
  liveness: number;
  snapshot: string | null;
  device?: string;
}): Promise<CheckInResponse> {
  try {
    const res = await request<CheckInResponse>("/api/checkin", { method: "POST", body: JSON.stringify(payload) });
    void flushQueue();
    return res;
  } catch (e) {
    const offline = offlineCheckIn(payload);
    if (offline) {
      queueOffline(offline);
      return { ...offline, offline: true };
    }
    throw e instanceof Error ? e : new Error("Network unavailable");
  }
}

/* --------------------------- offline / mock JSON DB ------------------------ */

interface OfflineLog {
  id: string;
  user_id: string;
  timestamp: string;
  status: string;
  event_type: string;
  confidence: number;
  method: "offline";
}

/** Match against the localStorage mirror of the template store. */
export function offlineCheckIn(payload: { template: Template; event: "check_in" | "check_out" }) {
  const roster = cachedRoster().filter((u) => u.status === "active");
  let best: { user: UserRecord; score: number } | null = null;
  for (const u of roster) {
    if (!u.templates?.length) continue;
    const { score } = scoreTemplates(u.templates, payload.template);
    if (!best || score > best.score) best = { user: u, score };
  }
  if (!best) return null;
  const cfg = readLS<SystemConfig>(LS.mirror + ".config", { matchThreshold: 0.72, margin: 0.03, lateCutoff: "09:15", snapshots: true });
  if (best.score < cfg.matchThreshold) return null;
  const log: OfflineLog = {
    id: `off_${Date.now()}`,
    user_id: best.user.id,
    timestamp: new Date().toISOString(),
    status: payload.event === "check_out" ? "checked_out" : "present",
    event_type: payload.event,
    confidence: Number(best.score.toFixed(4)),
    method: "offline",
  };
  return {
    ok: true as const,
    offline: true as const,
    score: best.score,
    threshold: cfg.matchThreshold,
    margin: 0,
    latencyMs: 0,
    user: best.user,
    log: { ...log, userId: log.user_id, name: best.user.name, role: best.user.role, photoUrl: best.user.photoUrl } as unknown as LogRecord,
  };
}

function queueOffline(entry: { log: OfflineLog | LogRecord }) {
  const q = readLS<unknown[]>(LS.queue, []);
  writeLS(LS.queue, [...q, entry.log]);
}

export function queuedCount() {
  return readLS<unknown[]>(LS.queue, []).length;
}

export async function flushQueue() {
  const q = readLS<OfflineLog[]>(LS.queue, []);
  if (!q.length) return 0;
  try {
    await request<{ synced: number }>("/api/attendance/sync", { method: "POST", body: JSON.stringify({ logs: q }) });
    writeLS(LS.queue, []);
    return q.length;
  } catch {
    return 0;
  }
}

/* ------------------------------- attendance -------------------------------- */

export interface SystemConfig {
  matchThreshold: number;
  margin: number;
  lateCutoff: string;
  snapshots: boolean;
}

export interface FeedPayload {
  date: string;
  totals: {
    registered: number;
    enrolled: number;
    present: number;
    late: number;
    absent: number;
    excused: number;
    checkedOut: number;
    denied: number;
    attendanceRate: number;
    scans: number;
    meanConfidence: number;
  };
  hourly: { hour: number; count: number }[];
  week: { date: string; label: string; present: number; late: number; absent: number }[];
  logs: LogRecord[];
  review: LogRecord[];
  roster: UserRecord[];
  config: SystemConfig;
  updatedAt: string;
}

export function fetchFeed() {
  return request<FeedPayload>("/api/attendance").then((d) => {
    writeLS(LS.logs, d.logs.slice(0, 40));
    return d;
  });
}

export function saveLastResult(r: unknown) {
  writeLS(LS.lastResult, r);
}

/* --------------------------------- admin ---------------------------------- */

export async function authorize(passcode: string) {
  const res = await request<{ ok: boolean }>("/api/auth/admin", { method: "POST", body: JSON.stringify({ passcode }) });
  writeLS(LS.passcode, true);
  return res;
}

export function signOut() {
  writeLS(LS.passcode, false);
  return request<{ ok: boolean }>("/api/auth/admin", { method: "DELETE" });
}

export function markAttendance(userId: string, status: string) {
  return request<{ ok: boolean }>("/api/attendance/mark", { method: "POST", body: JSON.stringify({ userId, status }) });
}

export function saveConfig(patch: Partial<SystemConfig>) {
  return request<SystemConfig>("/api/config", { method: "PATCH", body: JSON.stringify(patch) });
}

export function resetDay(scope: "today" | "all") {
  return request<{ removed: number }>("/api/attendance/reset", { method: "POST", body: JSON.stringify({ scope }) });
}

export function setPreference(key: keyof typeof LS, value: unknown) {
  writeLS(LS[key], value);
}
