import { createHash } from "node:crypto";
import { asc, desc, eq, gte, sql } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { attendanceLogs, systemConfig, users, type LogRow, type UserRow } from "@/db/schema";
import {
  DEFAULT_LATE_CUTOFF,
  DEFAULT_MARGIN,
  DEFAULT_MATCH_THRESHOLD,
  isLate,
  startOfDay,
  type LogRecord,
  type UserRecord,
} from "./shared";

export const COOKIE = "frs_admin";

export interface RuntimeConfig {
  matchThreshold: number;
  margin: number;
  lateCutoff: string;
  snapshots: boolean;
}

export const DEFAULT_CONFIG: RuntimeConfig = {
  matchThreshold: Number(process.env.FRS_MATCH_THRESHOLD ?? DEFAULT_MATCH_THRESHOLD),
  margin: DEFAULT_MARGIN,
  lateCutoff: DEFAULT_LATE_CUTOFF,
  snapshots: true,
};

/* ------------------------------- auth ---------------------------------- */

export function adminToken() {
  const pass = process.env.ADMIN_PASSCODE ?? "frs-admin";
  return createHash("sha256").update(`${pass}::frs-attest::v2`).digest("hex").slice(0, 40);
}

export async function isAdmin(req: Request) {
  const jar = req.headers.get("cookie") ?? (await cookies()).toString();
  const match = new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`).exec(jar);
  return match?.[1] === adminToken();
}

export async function requireAdmin(req: Request) {
  if (!(await isAdmin(req))) {
    return Response.json({ error: "Administrator authorisation required" }, { status: 401 });
  }
  return null;
}

/* ------------------------------ config --------------------------------- */

export async function getConfig(): Promise<RuntimeConfig> {
  try {
    const row = await db.select().from(systemConfig).where(eq(systemConfig.key, "runtime")).limit(1);
    const value = row[0]?.value as Partial<RuntimeConfig> | undefined;
    if (!value) return DEFAULT_CONFIG;
    return {
      matchThreshold: typeof value.matchThreshold === "number" ? value.matchThreshold : DEFAULT_CONFIG.matchThreshold,
      margin: typeof value.margin === "number" ? value.margin : DEFAULT_CONFIG.margin,
      lateCutoff: typeof value.lateCutoff === "string" ? value.lateCutoff : DEFAULT_CONFIG.lateCutoff,
      snapshots: typeof value.snapshots === "boolean" ? value.snapshots : DEFAULT_CONFIG.snapshots,
    };
  } catch {
    return DEFAULT_CONFIG;
  }
}

function clampNum(v: unknown, lo: number, hi: number, fallback: number) {
  const n = typeof v === "number" ? v : Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, n));
}

export async function saveConfig(patch: Partial<RuntimeConfig>): Promise<RuntimeConfig> {
  const current = await getConfig();
  const next: RuntimeConfig = {
    matchThreshold: clampNum(patch.matchThreshold, 0.4, 0.98, current.matchThreshold),
    margin: clampNum(patch.margin, 0, 0.3, current.margin),
    lateCutoff: typeof patch.lateCutoff === "string" && /^\d{1,2}:\d{2}$/.test(patch.lateCutoff) ? patch.lateCutoff : current.lateCutoff,
    snapshots: typeof patch.snapshots === "boolean" ? patch.snapshots : current.snapshots,
  };
  await db
    .insert(systemConfig)
    .values({ key: "runtime", value: next, updatedAt: new Date() })
    .onConflictDoUpdate({ target: systemConfig.key, set: { value: next, updatedAt: new Date() } });
  return next;
}

/* ------------------------------ mapping -------------------------------- */

export function mapUser(row: UserRow, opts: { withTemplates?: boolean } = {}): UserRecord {
  const out: UserRecord = {
    id: row.id,
    name: row.name,
    role: row.role,
    email: row.email,
    department: row.department,
    photoUrl: row.photoUrl,
    samples: row.samples,
    faceQuality: Number(row.faceQuality ?? 0),
    distinctiveness: Number(row.distinctiveness ?? 0),
    status: row.status,
    source: row.source,
    lastSeenAt: row.lastSeenAt ? row.lastSeenAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
  };
  if (opts.withTemplates) out.templates = (row.embeddings ?? []) as UserRecord["templates"];
  return out;
}

type JoinedLog = Omit<LogRow, "device"> & { device?: string | null; name?: string | null; role?: string | null; photoUrl?: string | null };

export function mapLog(row: JoinedLog): LogRecord {
  return {
    id: row.id,
    userId: row.userId,
    name: row.name ?? null,
    role: row.role ?? null,
    photoUrl: row.photoUrl ?? null,
    timestamp: row.timestamp.toISOString(),
    status: row.status as LogRecord["status"],
    eventType: row.eventType as LogRecord["eventType"],
    method: row.method as LogRecord["method"],
    confidence: row.confidence == null ? null : Number(row.confidence),
    liveness: row.liveness == null ? null : Number(row.liveness),
    snapshot: row.snapshot,
    note: row.note,
  };
}

/* -------------------------------- feed --------------------------------- */

const LOG_WITH_USER = {
  id: attendanceLogs.id,
  userId: attendanceLogs.userId,
  timestamp: attendanceLogs.timestamp,
  status: attendanceLogs.status,
  eventType: attendanceLogs.eventType,
  method: attendanceLogs.method,
  confidence: attendanceLogs.confidence,
  liveness: attendanceLogs.liveness,
  snapshot: attendanceLogs.snapshot,
  note: attendanceLogs.note,
  device: attendanceLogs.device,
  name: users.name,
  role: users.role,
  photoUrl: users.photoUrl,
};

export async function buildFeed() {
  await ensureSeeded();
  const cfg = await getConfig();
  const todayStart = startOfDay(new Date());
  const windowStart = new Date(todayStart.getTime() - 6 * 86400000);

  const [userRows, todayRows, windowRows] = await Promise.all([
    db.select().from(users).orderBy(asc(users.name)),
    db
      .select(LOG_WITH_USER)
      .from(attendanceLogs)
      .leftJoin(users, eq(attendanceLogs.userId, users.id))
      .where(gte(attendanceLogs.timestamp, todayStart))
      .orderBy(desc(attendanceLogs.timestamp))
      .limit(160),
    db
      .select({
        timestamp: attendanceLogs.timestamp,
        status: attendanceLogs.status,
        eventType: attendanceLogs.eventType,
        userId: attendanceLogs.userId,
      })
      .from(attendanceLogs)
      .where(gte(attendanceLogs.timestamp, windowStart)),
  ]);

  const todayLogs = todayRows.map(mapLog);

  const dayKey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const byDay = new Map<string, { present: Set<string>; late: Set<string>; absent: Set<string> }>();
  for (let i = 0; i < 7; i++) {
    const d = new Date(todayStart.getTime() + i * 86400000);
    byDay.set(dayKey(d), { present: new Set(), late: new Set(), absent: new Set() });
  }
  for (const r of windowRows) {
    const bucket = byDay.get(dayKey(r.timestamp));
    if (!bucket || !r.userId || r.eventType === "check_out") continue;
    if (r.status === "present") bucket.present.add(r.userId);
    if (r.status === "late") {
      bucket.late.add(r.userId);
      bucket.present.add(r.userId);
    }
    if (r.status === "absent" || r.status === "excused") bucket.absent.add(r.userId);
  }
  const week = Array.from(byDay.entries()).map(([date, v]) => ({
    date,
    label: new Date(`${date}T12:00:00`).toLocaleDateString("en-US", { weekday: "short" }).slice(0, 2),
    present: Math.max(0, v.present.size - v.late.size),
    late: v.late.size,
    absent: v.absent.size,
  }));

  // rolling 14-hour window that always contains "now"
  const endHour = Math.max(10, Math.min(23, new Date().getHours() + 1));
  const startHour = Math.max(0, endHour - 13);
  const hourly = Array.from({ length: endHour - startHour + 1 }, (_, i) => {
    const hour = startHour + i;
    return { hour, count: todayLogs.filter((l) => l.eventType === "check_in" && new Date(l.timestamp).getHours() === hour).length };
  });

  const active = userRows.filter((u) => u.status === "active");
  const enrolled = active.filter((u) => u.samples > 0);
  const checkIns = todayLogs.filter((l) => l.eventType === "check_in" && l.userId);
  const presentIds = new Set(checkIns.map((l) => l.userId as string));
  const lateIds = new Set(todayLogs.filter((l) => l.status === "late" && l.userId).map((l) => l.userId as string));
  const excusedIds = new Set(todayLogs.filter((l) => (l.status === "excused" || l.status === "absent") && l.userId).map((l) => l.userId as string));
  const outIds = new Set(todayLogs.filter((l) => l.eventType === "check_out" && l.userId).map((l) => l.userId as string));

  const roster = userRows.map((u) => {
    const rec = mapUser(u);
    const mine = todayLogs.filter((l) => l.userId === u.id);
    const inLog = mine.find((l) => l.eventType === "check_in");
    const outLog = mine.find((l) => l.eventType === "check_out");
    const mark = mine.find((l) => l.status === "excused" || l.status === "absent");
    rec.todayStatus = inLog ? (outLog ? "checked_out" : inLog.status) : mark ? mark.status : u.status === "active" ? "absent" : "absent";
    rec.todayCheckIn = inLog?.timestamp ?? null;
    return rec;
  });

  const present = active.filter((u) => presentIds.has(u.id)).length;
  const late = active.filter((u) => lateIds.has(u.id)).length;
  const excused = active.filter((u) => excusedIds.has(u.id) && !presentIds.has(u.id)).length;
  const absent = Math.max(0, active.length - present - excused);
  const confidences = checkIns.map((l) => l.confidence ?? 0).filter((c) => c > 0);

  return {
    date: new Date().toISOString(),
    totals: {
      registered: userRows.length,
      enrolled: enrolled.length,
      present,
      late,
      absent,
      excused,
      checkedOut: active.filter((u) => outIds.has(u.id)).length,
      denied: todayLogs.filter((l) => l.status === "denied").length,
      attendanceRate: active.length ? present / active.length : 0,
      scans: todayLogs.filter((l) => l.method === "face").length,
      meanConfidence: confidences.length ? confidences.reduce((a, b) => a + b, 0) / confidences.length : 0,
    },
    hourly,
    week,
    logs: todayLogs.slice(0, 40),
    review: todayLogs.filter((l) => l.status === "denied").slice(0, 12),
    roster,
    config: cfg,
    updatedAt: new Date().toISOString(),
  };
}

/* ------------------------------ seeding -------------------------------- */

declare global {
  // eslint-disable-next-line no-var
  var __frsSeed: Promise<boolean> | null | undefined;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Synthetic templates for the demo roster so dashboards have history. */
function syntheticTemplate(seedText: string, salt: number) {
  let h = 2166136261;
  for (const ch of seedText) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  const rnd = mulberry32(h + salt * 7919);
  const build = (len: number) => {
    const v = new Float64Array(len);
    for (let i = 0; i < len; i++) v[i] = rnd() - 0.5 + Math.sin(i / 5 + salt) * 0.05;
    let norm = 0;
    for (let i = 0; i < len; i++) norm += v[i] * v[i];
    norm = Math.sqrt(norm) || 1;
    return Array.from(v, (n) => Math.round((n / norm) * 1e4) / 1e4);
  };
  return { hog: build(512), texture: build(256) };
}

const DEMO_ROSTER: [string, string, string][] = [
  ["Amara Okafor", "Shift Lead", "Operations"],
  ["Diego Ferrer", "Engineer", "Engineering"],
  ["Priya Raghavan", "Manager", "Security"],
  ["Tomas Lindqvist", "Employee", "Logistics"],
  ["Nia Bennett", "Engineer", "Engineering"],
  ["Kazuki Mori", "Contractor", "Field"],
  ["Sofia Marchetti", "Employee", "Reception"],
  ["Ravi Chandran", "Employee", "Operations"],
];

async function runSeed() {
  const [existing] = await db.select({ c: sql<number>`count(*)::int` }).from(users);
  if ((existing?.c ?? 0) > 0) return false;

  const created: { id: string; name: string }[] = [];
  for (const [name, role, department] of DEMO_ROSTER) {
    const embeddings = [syntheticTemplate(name, 1), syntheticTemplate(name, 2)];
    const inserted = await db
      .insert(users)
      .values({
        name,
        role,
        department,
        email: `${name.split(" ")[0]!.toLowerCase()}@frs.demo`,
        source: "seed",
        status: "active",
        samples: embeddings.length,
        embeddings,
        faceQuality: 0.62 + (name.length % 5) * 0.05,
        distinctiveness: 0.94,
      })
      .returning({ id: users.id, name: users.name });
    created.push(...inserted);
  }

  const today = startOfDay();
  const nowMs = Date.now();
  const rows = [];
  for (let d = 9; d >= 0; d--) {
    for (let idx = 0; idx < created.length; idx++) {
      const u = created[idx]!;
      const isToday = d === 0;
      const rnd = mulberry32(d * 31 + u.name.charCodeAt(0) + u.name.length);
      const skip = !isToday && rnd() < 0.12;
      const excused = !skip && rnd() < (isToday ? 0.1 : 0.08);
      if (excused) {
        rows.push({
          userId: u.id,
          timestamp: new Date(today.getTime() - d * 86400000 + 8 * 3600000),
          status: "excused",
          eventType: "manual",
          method: "seed",
          confidence: 0,
          liveness: 0,
          note: "Pre-approved absence",
          device: "seed-loader",
        });
        continue;
      }
      if (skip) continue;
      // historic days follow a fixed 08:20–09:40 shift band; today streams in
      // behind the current clock so the live console always has a signal.
      const ts = isToday
        ? new Date(nowMs - (3 * 60000 + idx * 20 * 60000 + Math.floor(rnd() * 9) * 60000))
        : new Date(today.getTime() - d * 86400000 + (8 * 60 + Math.floor(rnd() * 78) - 12) * 60000);
      if (ts.getTime() > nowMs) continue;
      const late = isLate(ts, DEFAULT_LATE_CUTOFF) || (isToday && rnd() < 0.28);
      rows.push({
        userId: u.id,
        timestamp: ts,
        status: late ? "late" : "present",
        eventType: "check_in",
        method: "seed",
        confidence: Number((0.74 + rnd() * 0.2).toFixed(4)),
        liveness: Number((0.82 + rnd() * 0.16).toFixed(3)),
        note: late ? "Arrived after cutoff" : null,
        device: "seed-loader",
      });
      const outOffset = (7 + Math.floor(rnd() * 4)) * 3600000;
      if (!isToday && rnd() > 0.4) {
        rows.push({
          userId: u.id,
          timestamp: new Date(ts.getTime() + outOffset),
          status: "checked_out",
          eventType: "check_out",
          method: "seed",
          confidence: Number((0.7 + rnd() * 0.25).toFixed(4)),
          liveness: 0.9,
          note: null,
          device: "seed-loader",
        });
      }
    }
  }

  if (rows.length) await db.insert(attendanceLogs).values(rows);

  await db.insert(attendanceLogs).values([
    {
      userId: null,
      timestamp: new Date(Date.now() - 1000 * 60 * 42),
      status: "denied",
      eventType: "denied",
      method: "face",
      confidence: 0.41,
      liveness: 0.88,
      note: "Unenrolled face · below threshold",
      device: "kiosk-01",
    },
    {
      userId: null,
      timestamp: new Date(Date.now() - 1000 * 60 * 96),
      status: "denied",
      eventType: "denied",
      method: "face",
      confidence: 0.58,
      liveness: 0.21,
      note: "Liveness guard · static frame",
      device: "kiosk-02",
    },
  ]);

  return true;
}

export function ensureSeeded() {
  if (!globalThis.__frsSeed) {
    globalThis.__frsSeed = runSeed().catch((e: unknown) => {
      globalThis.__frsSeed = null;
      console.error("[frs] seeding skipped:", e instanceof Error ? e.message : e);
      return false;
    });
  }
  return globalThis.__frsSeed as Promise<boolean>;
}

export async function wipeDay(scope: "today" | "all") {
  if (scope === "all") {
    await db.delete(attendanceLogs);
    await db.delete(users);
    await db.delete(systemConfig);
    globalThis.__frsSeed = null;
    return { removed: -1 };
  }
  const res = await db.delete(attendanceLogs).where(gte(attendanceLogs.timestamp, startOfDay(new Date())));
  return { removed: Array.isArray(res) ? 0 : ((res as unknown as { rowCount?: number }).rowCount ?? 0) };
}
