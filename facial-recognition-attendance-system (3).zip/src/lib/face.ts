// ---------------------------------------------------------------------------
// FRS face pipeline (browser only, zero dependencies, deterministic).
//
//   frame -> [face localisation] -> [96x96 normalised patch]
//         -> HOG 8x8 cells x 8 bins        (512-d structural descriptor)
//         -> high-pass residual 16x16      (256-d texture descriptor)
//         -> cosine similarity fusion      -> match / no-match
//
// If the experimental native FaceDetector API is available it is preferred,
// otherwise an YCbCr skin-chrominance projection localises the head.
// ---------------------------------------------------------------------------

import {
  ANALYSIS_H,
  ANALYSIS_W,
  FACE_CANVAS,
  clamp01,
  type FrameMetric,
  type QualityReport,
  type Template,
} from "./shared";

export interface FaceBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

type FrameSource = HTMLVideoElement | HTMLCanvasElement | HTMLImageElement;

const canvasCache = new Map<string, HTMLCanvasElement>();

function surface(key: string, w: number, h: number) {
  const existing = canvasCache.get(key);
  if (existing) {
    if (existing.width !== w) existing.width = w;
    if (existing.height !== h) existing.height = h;
    existing.getContext("2d", { willReadFrequently: true })!.clearRect(0, 0, w, h);
    return existing;
  }
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  canvasCache.set(key, c);
  return c;
}

function srcSize(src: FrameSource) {
  if (src instanceof HTMLVideoElement) return { w: src.videoWidth || src.width, h: src.videoHeight || src.height };
  return { w: src.width, h: src.height };
}

export function grabFrame(src: FrameSource, w: number, h: number): ImageData | null {
  const c = surface(`grab-${w}x${h}`, w, h);
  const ctx = c.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  try {
    ctx.drawImage(src, 0, 0, w, h);
    return ctx.getImageData(0, 0, w, h);
  } catch {
    return null;
  }
}

function lumaOf(img: ImageData, out?: Float64Array) {
  const n = img.width * img.height;
  const y = out && out.length >= n ? out : new Float64Array(n);
  const d = img.data;
  for (let i = 0, p = 0; i < n; i++, p += 4) {
    y[i] = 0.299 * d[p]! + 0.587 * d[p + 1]! + 0.114 * d[p + 2]!;
  }
  return y;
}

/** Skin chrominance test in RGB + YCbCr space. */
function isSkin(r: number, g: number, b: number) {
  const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
  const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
  const mx = Math.max(r, g, b);
  const mn = Math.min(r, g, b);
  return (
    r > 70 && g > 34 && b > 18 && r > g && r >= b && mx - mn > 12 && Math.abs(r - g) > 8 && cb >= 77 && cb <= 133 && cr >= 133 && cr <= 176
  );
}

/** Projection-based head localisation on a downscaled frame. */
export function detectFaceHeuristic(img: ImageData): { box: FaceBox; coverage: number } | null {
  const { width: W, height: H, data } = img;
  const cols = new Float64Array(W);
  const rows = new Float64Array(H);
  let count = 0;

  for (let y = 0; y < H; y++) {
    // centre-weighted: the operator stands in front of the lens
    const rowBias = 1 - Math.abs((y + 0.5) / H - 0.45) * 0.55;
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      if (isSkin(data[i]!, data[i + 1]!, data[i + 2]!)) {
        const colBias = 1 - Math.abs((x + 0.5) / W - 0.5) * 0.5;
        const wgt = rowBias * colBias;
        cols[x]! += wgt;
        rows[y]! += wgt;
        count += wgt;
      }
    }
  }

  const coverage = count / (W * H);
  if (coverage < 0.035) return null;

  const trim = (arr: Float64Array) => {
    const peak = Math.max(...arr);
    let lo = 0;
    let hi = arr.length - 1;
    while (lo < arr.length && arr[lo]! < peak * 0.28) lo++;
    while (hi >= 0 && arr[hi]! < peak * 0.28) hi--;
    return [lo, hi] as const;
  };

  const [x0, x1] = trim(cols);
  const [y0, y1] = trim(rows);
  if (x1 <= x0 || y1 <= y0) return null;

  let w = (x1 - x0 + 1) / W;
  let h = (y1 - y0 + 1) / H;
  // enforce head proportions (skin blob ≈ face, add crown + chin margin)
  const aspect = (w * W) / (h * H || 1);
  if (aspect < 0.95) w = (h * H * 0.95) / W;
  else h = (w * W) / (0.95 * H);
  w = clamp01(w * 1.34);
  h = clamp01(h * 1.42);

  const cx = (x0 + (x1 - x0) / 2) / W;
  const cy = (y0 + (y1 - y0) / 2) / H - h * 0.08;

  return {
    box: {
      w,
      h,
      x: Math.min(Math.max(cx - w / 2, 0), 1 - w),
      y: Math.min(Math.max(cy - h / 2, 0), 1 - h),
    },
    coverage,
  };
}

export async function detectFaceNative(src: FrameSource): Promise<FaceBox | null> {
  const DetectorCtor = (globalThis as unknown as { FaceDetector?: new (o?: { fastMode?: boolean }) => { detect: (s: FrameSource) => Promise<{ boundingBox: DOMRectReadOnly }[]> } }).FaceDetector;
  if (!DetectorCtor) return null;
  try {
    const det = new DetectorCtor({ fastMode: true });
    const faces = await det.detect(src);
    const first = faces[0];
    if (!first) return null;
    const { w, h } = srcSize(src);
    const b = first.boundingBox;
    return { x: b.x / w, y: b.y / h, w: b.width / w, h: b.height / h };
  } catch {
    return null;
  }
}

function roundAll(v: Float64Array | number[], dp = 4) {
  const f = Math.pow(10, dp);
  return Array.from(v, (n) => Math.round(n * f) / f);
}

function l2Normalize(v: Float64Array) {
  let norm = 0;
  for (let i = 0; i < v.length; i++) norm += v[i]! * v[i]!;
  norm = Math.sqrt(norm) || 1;
  for (let i = 0; i < v.length; i++) v[i] = v[i] / norm;
  return v;
}

export interface Extraction {
  template: Template;
  quality: QualityReport;
  patchDataUrl: string;
}

/** Normalised face patch -> descriptors + capture quality report. */
export function extractFromSource(src: FrameSource, box: FaceBox): Extraction | null {
  const { w: SW, h: SH } = srcSize(src);
  if (!SW || !SH) return null;
  const S = FACE_CANVAS;
  const c = surface("face-patch", S, S);
  const ctx = c.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  const sx = box.x * SW;
  const sy = box.y * SH;
  const sw = Math.max(8, box.w * SW);
  const sh = Math.max(8, box.h * SH);
  ctx.clearRect(0, 0, S, S);
  ctx.drawImage(src, sx, sy, sw, sh, 0, 0, S, S);

  const patch = ctx.getImageData(0, 0, S, S);
  const raw = lumaOf(patch);
  const n = S * S;

  let mean = 0;
  for (let i = 0; i < n; i++) mean += raw[i]!;
  mean /= n;
  let sd = 0;
  for (let i = 0; i < n; i++) sd += (raw[i]! - mean) ** 2;
  sd = Math.sqrt(sd / n);

  // illumination-invariant normalisation
  const x = new Float64Array(n);
  const scale = 1 / Math.max(sd, 9);
  for (let i = 0; i < n; i++) x[i] = (raw[i] - mean) * scale;

  // --- HOG: 8x8 cells, 8 unsigned orientation bins -------------------------
  const CELLS = 8;
  const BINS = 8;
  const CELL = S / CELLS; // 12px
  const hist = new Float64Array(CELLS * CELLS * BINS);
  for (let y = 1; y < S - 1; y++) {
    for (let cx = 1; cx < S - 1; cx++) {
      const i = y * S + cx;
      const gx = x[i + 1]! - x[i - 1]!;
      const gy = x[i + S]! - x[i - S]!;
      const mag = Math.hypot(gx, gy);
      if (mag < 1e-4) continue;
      let ang = Math.atan2(gy, gx); // -pi..pi
      if (ang < 0) ang += Math.PI; // unsigned 0..pi
      const bin = Math.floor((ang / Math.PI) * BINS) % BINS;
      const cellIdx = Math.min(CELLS - 1, Math.floor(y / CELL)) * CELLS + Math.min(CELLS - 1, Math.floor(cx / CELL));
      hist[cellIdx * BINS + bin] += mag;
      hist[cellIdx * BINS + ((bin + 1) % BINS)] += mag * 0.25;
      hist[cellIdx * BINS + ((bin - 1 + BINS) % BINS)] += mag * 0.25;
    }
  }
  for (let cIdx = 0; cIdx < CELLS * CELLS; cIdx++) {
    const start = cIdx * BINS;
    let e = 0;
    for (let b = 0; b < BINS; b++) e += hist[start + b]! * hist[start + b]!;
    e = Math.sqrt(e) + 0.05;
    for (let b = 0; b < BINS; b++) hist[start + b] = Math.min(hist[start + b]! / e, 0.22);
  }
  l2Normalize(hist);

  // --- texture: high-pass residual of a 16x16 block grid --------------------
  const T = 16;
  const cell = S / T; // 6px
  const block = new Float64Array(T * T);
  for (let by = 0; by < T; by++) {
    for (let bx = 0; bx < T; bx++) {
      let sum = 0;
      let cnt = 0;
      for (let yy = Math.floor(by * cell); yy < Math.floor((by + 1) * cell); yy++) {
        for (let xx = Math.floor(bx * cell); xx < Math.floor((bx + 1) * cell); xx++) {
          sum += x[yy * S + xx]!;
          cnt++;
        }
      }
      block[by * T + bx] = cnt ? sum / cnt : 0;
    }
  }
  const half = T / 2;
  const tex = new Float64Array(T * T);
  for (let by = 0; by < T; by++) {
    for (let bx = 0; bx < T; bx++) {
      let sum = 0;
      let cnt = 0;
      for (let yy = Math.max(0, by - half); yy < Math.min(T, by + half); yy++) {
        for (let xx = Math.max(0, bx - half); xx < Math.min(T, bx + half); xx++) {
          sum += block[yy * T + xx]!;
          cnt++;
        }
      }
      tex[by * T + bx] = block[by * T + bx]! - sum / Math.max(cnt, 1);
    }
  }
  l2Normalize(tex);

  // --- quality metrics -------------------------------------------------------
  let lap = 0;
  let lapN = 0;
  for (let y = 1; y < S - 1; y++) {
    for (let cx = 1; cx < S - 1; cx++) {
      const i = y * S + cx;
      const v = 4 * raw[i]! - raw[i - 1]! - raw[i + 1]! - raw[i - S]! - raw[i + S]!;
      lap += v * v;
      lapN++;
    }
  }
  const lapVar = lapN ? lap / lapN : 0;
  const faceCx = box.x + box.w / 2;
  const faceCy = box.y + box.h / 2;
  const off = Math.hypot(faceCx - 0.5, faceCy - 0.46);

  const quality: QualityReport = {
    brightness: clamp01(1 - Math.abs(mean - 126) / 82),
    contrast: clamp01(sd / 46),
    sharpness: clamp01(lapVar / 460),
    size: clamp01((box.w * box.h * SW * SH) / (0.22 * SW * SH) / 3),
    centering: clamp01(1 - off * 2.1),
    overall: 0,
  };
  quality.overall = clamp01(quality.brightness * 0.2 + quality.contrast * 0.2 + quality.sharpness * 0.34 + quality.size * 0.12 + quality.centering * 0.14);

  return {
    template: { hog: roundAll(hist), texture: roundAll(tex) },
    quality,
    patchDataUrl: c.toDataURL("image/jpeg", 0.62),
  };
}

export function dot(a: number[] | Float64Array, b: number[] | Float64Array) {
  const len = Math.min(a.length, b.length);
  let s = 0;
  for (let i = 0; i < len; i++) s += (a[i] || 0) * (b[i] || 0);
  return s;
}

/** Fused similarity across the structural and texture descriptors. */
export function similarity(a: Template, b: Template) {
  const hog = dot(a.hog, b.hog);
  const tex = dot(a.texture, b.texture);
  return Math.max(0, Math.min(1, 0.45 * hog + 0.55 * tex));
}

export function scoreTemplates(templates: Template[], probe: Template) {
  let best = 0;
  let count = 0;
  for (const t of templates) {
    const s = similarity(t, probe);
    if (s > best) best = s;
    if (s > 0.25) count++;
  }
  return { score: best, hits: count };
}

export type LiveMetric = FrameMetric & { patch?: Extraction };

export interface Analyzer {
  measure(src: FrameSource, box: FaceBox | null): FrameMetric;
}

/** Reusable per-frame analyser for the live HUD (retains last luma for motion). */
export function createAnalyzer(): Analyzer {
  let prev: Float64Array | null = null;
  let last = performance.now();
  let fps = 0;

  return {
    measure(src: FrameSource, override: FaceBox | null): FrameMetric {
      const frame = grabFrame(src, ANALYSIS_W, ANALYSIS_H);
      const now = performance.now();
      const dt = Math.max(16, now - last);
      last = now;
      fps = fps ? fps * 0.75 + (1000 / dt) * 0.25 : 1000 / dt;

      if (!frame) {
        return {
          hasFace: false,
          box: { x: 0.25, y: 0.16, w: 0.5, h: 0.66 },
          detector: "center",
          motion: 0,
          fps,
          quality: { brightness: 0, contrast: 0, sharpness: 0, size: 0, centering: 0, overall: 0 },
        };
      }

      const cur = lumaOf(frame);
      let motion = 0;
      if (prev) {
        let acc = 0;
        for (let i = 0; i < cur.length; i += 3) acc += Math.abs(cur[i]! - prev[i]!);
        motion = acc / (cur.length / 3);
      }
      prev = cur;

      const heuristic = detectFaceHeuristic(frame);
      const box: FaceBox = override ?? heuristic?.box ?? { x: 0.26, y: 0.12, w: 0.48, h: 0.7 };
      const detector: FrameMetric["detector"] = override ? "detector" : heuristic ? "heuristic" : "center";

      const ex = extractFromSource(src, box);
      const quality = ex?.quality ?? { brightness: 0, contrast: 0, sharpness: 0, size: 0, centering: 0, overall: 0 };

      return {
        hasFace: detector !== "center" || quality.overall > 0.25,
        box,
        detector,
        quality,
        motion: clamp01(motion / 6),
        fps: Math.round(fps),
        ...(ex ? { patch: ex } : {}),
      } as FrameMetric;
    },
  };
}

/** JPEG snapshot for the manual review queue (unknown faces only). */
export function snapshot(src: FrameSource, box: FaceBox | null, size = 168) {
  const S = size;
  const c = surface("snapshot", S, S);
  const ctx = c.getContext("2d");
  if (!ctx) return null;
  const { w: SW, h: SH } = srcSize(src);
  const b = box ?? { x: 0.26, y: 0.12, w: 0.48, h: 0.7 };
  ctx.fillStyle = "#0b1017";
  ctx.fillRect(0, 0, S, S);
  try {
    ctx.drawImage(src, b.x * SW - (b.w * SW) * 0.18, b.y * SH - (b.h * SH) * 0.22, b.w * SW * 1.36, b.h * SH * 1.5, 0, 0, S, S);
  } catch {
    return null;
  }
  return c.toDataURL("image/jpeg", 0.55);
}
