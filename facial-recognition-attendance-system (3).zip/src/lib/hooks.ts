"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/** Scroll-triggered reveal (adds `.is-in` to elements carrying `.reveal`). */
export function useReveal(deps: unknown[] = []) {
  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>(".reveal:not(.is-in)"));
    if (!("IntersectionObserver" in window) || nodes.length === 0) {
      nodes.forEach((n) => n.classList.add("is-in"));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            (e.target as HTMLElement).classList.add("is-in");
            io.unobserve(e.target);
          }
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );
    nodes.forEach((n) => io.observe(n));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

/** Ticking clock (1s) for kiosk HUDs. */
export function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}

/** Animated number count-up used across dashboard KPIs. */
export function useCountUp(value: number, duration = 900) {
  const [display, setDisplay] = useState(value);
  const fromRef = useRef(value);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const from = fromRef.current;
    const to = value;
    if (from === to) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      fromRef.current = to;
      setDisplay(to);
      return;
    }
    const t0 = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (to - from) * eased);
      if (p < 1) rafRef.current = requestAnimationFrame(step);
      else fromRef.current = to;
    };
    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      fromRef.current = to;
    };
  }, [value, duration]);

  return display;
}

export interface Toast {
  id: number;
  tone: "go" | "stop" | "signal" | "scan";
  title: string;
  body?: string;
}

export function useToasts() {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const seq = useRef(0);

  const push = useCallback((title: string, body?: string, tone: Toast["tone"] = "scan") => {
    const id = ++seq.current;
    setToasts((t) => [...t, { id, tone, title, body }].slice(-4));
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4600);
  }, []);
  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  return { toasts, push, dismiss };
}

/**
 * Live polling + cross-tab broadcast so a kiosk check-in appears in the
 * admin console instantly without a manual refresh.
 */
export function useLiveFeed<T>(loader: () => Promise<T>, opts: { interval?: number; channel?: string; enabled?: boolean } = {}) {
  const { interval = 5000, channel = "frs-live", enabled = true } = opts;
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const loadRef = useRef(loader);
  loadRef.current = loader;

  const run = useCallback(
    async (silent = true) => {
      if (!silent) setBusy(true);
      try {
        const next = await loadRef.current();
        setData(next);
        setError(null);
        setUpdatedAt(Date.now());
      } catch (e) {
        setError(e instanceof Error ? e.message : "Feed unavailable");
      } finally {
        if (!silent) setBusy(false);
      }
    },
    [],
  );

  useEffect(() => {
    void run(false);
    if (!enabled) return;
    const id = window.setInterval(() => void run(true), interval);
    let bc: BroadcastChannel | null = null;
    try {
      bc = new BroadcastChannel(channel);
      bc.onmessage = () => void run(true);
    } catch {
      bc = null;
    }
    const onVis = () => {
      if (document.visibilityState === "visible") void run(true);
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(id);
      bc?.close();
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [run, interval, enabled, channel, run]);

  const broadcast = useCallback(() => {
    try {
      new BroadcastChannel(channel).postMessage({ t: Date.now() });
    } catch {
      /* noop */
    }
  }, [channel]);

  return { data, error, updatedAt, busy, refresh: () => run(false), broadcast };
}

/** Media query matcher (mobile responsive JS behaviour). */
export function useMediaQuery(query: string) {
  const [matches, setMatches] = useState(false);
  useEffect(() => {
    const mql = window.matchMedia(query);
    setMatches(mql.matches);
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches);
    mql.addEventListener("change", handler);
    return () => mql.removeEventListener("change", handler);
  }, [query]);
  return matches;
}

export function playTone(ok: boolean) {
  try {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    const ctx = new Ctor();
    const now = ctx.currentTime;
    const notes = ok ? [523.25, 784] : [311.13, 233.08];
    notes.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = ok ? "sine" : "triangle";
      osc.frequency.value = f;
      gain.gain.setValueAtTime(0.0001, now + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(ok ? 0.11 : 0.14, now + i * 0.12 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.12 + 0.22);
      osc.connect(gain).connect(ctx.destination);
      osc.start(now + i * 0.12);
      osc.stop(now + i * 0.12 + 0.26);
    });
    window.setTimeout(() => void ctx.close(), 900);
  } catch {
    /* audio is a nicety, never a blocker */
  }
}
