/**
 * Shared constants + types used by both the browser pipeline and the API.
 * Keep this module free of node/driver imports.
 */

export const HOG_DIM = 512; // 8x8 cells x 8 orientation bins
export const TEXTURE_DIM = 256; // 16x16 high-pass response
export const FACE_CANVAS = 96; // normalized face patch size (px)
export const ANALYSIS_W = 160;
export const ANALYSIS_H = 120;

export const DEFAULT_MATCH_THRESHOLD = 0.72;
export const DEFAULT_MARGIN = 0.03;
export const DEFAULT_LATE_CUTOFF = "09:15";
export const DEFAULT_ADMIN_PASSCODE = "frs-admin";

export const ROLES = ["Employee", "Shift Lead", "Engineer", "Contractor", "Visitor", "Manager"] as const;
export const DEPARTMENTS = ["Operations", "Engineering", "Security", "Logistics", "Reception", "Field"] as const;

export type LogStatus = "present" | "late" | "checked_out" | "excused" | "absent" | "denied";
export type EventType = "check_in" | "check_out" | "denied" | "manual";
export type Method = "face" | "manual" | "offline" | "seed";

export interface Template {
  hog: number[];
  texture: number[];
}

export interface UserRecord {
  id: string;
  name: string;
  role: string;
  email: string | null;
  department: string;
  photoUrl: string | null;
  samples: number;
  faceQuality: number;
  distinctiveness: number;
  status: string;
  source: string;
  lastSeenAt: string | null;
  createdAt: string;
  /** only shipped to the device for offline kiosk matching */
  templates?: Template[];
  todayStatus?: LogStatus | null;
  todayCheckIn?: string | null;
}

export interface LogRecord {
  id: string;
  userId: string | null;
  name: string | null;
  role: string | null;
  photoUrl: string | null;
  timestamp: string;
  status: LogStatus;
  eventType: EventType;
  method: Method;
  confidence: number | null;
  liveness: number | null;
  snapshot: string | null;
  note: string | null;
}

export interface QualityReport {
  brightness: number;
  contrast: number;
  sharpness: number;
  size: number;
  centering: number;
  overall: number;
}

export interface FrameMetric {
  hasFace: boolean;
  box: { x: number; y: number; w: number; h: number };
  detector: "detector" | "heuristic" | "center";
  quality: QualityReport;
  motion: number;
  fps: number;
}

export const clamp01 = (n: number) => Math.min(1, Math.max(0, n));

export function statusMeta(status: LogStatus | string | null | undefined) {
  switch (status) {
    case "present":
      return { label: "Present", tone: "go" as const, dot: "#45d48c" };
    case "late":
      return { label: "Late", tone: "caution" as const, dot: "#ff9f4a" };
    case "checked_out":
      return { label: "Checked out", tone: "scan" as const, dot: "#34e0c6" };
    case "excused":
      return { label: "Excused", tone: "signal" as const, dot: "#f5b942" };
    case "absent":
      return { label: "Absent", tone: "muted" as const, dot: "#5d6b7a" };
    case "denied":
      return { label: "Denied", tone: "stop" as const, dot: "#ff6b72" };
    default:
      return { label: "—", tone: "muted" as const, dot: "#5d6b7a" };
  }
}

export const toneText: Record<string, string> = {
  go: "text-go-400",
  stop: "text-stop-400",
  caution: "text-caution-400",
  signal: "text-signal-400",
  scan: "text-scan-400",
  muted: "text-bone-500",
};

export function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "??";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[parts.length - 1]![0]!).toUpperCase();
}

export function formatClock(ts: string | number | Date | null | undefined) {
  if (!ts) return "--:--:--";
  const d = new Date(ts);
  return d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function formatHM(ts: string | number | Date | null | undefined) {
  if (!ts) return "--:--";
  return new Date(ts).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
}

export function formatDay(ts: string | number | Date) {
  return new Date(ts).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
}

export function relativeTime(ts: string | number | Date) {
  const diff = Date.now() - new Date(ts).getTime();
  const s = Math.round(diff / 1000);
  if (s < 45) return "just now";
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  const d = Math.round(s / 86400);
  return d === 1 ? "yesterday" : `${d}d ago`;
}

export function isLate(now: Date, cutoff: string) {
  const [h, m] = cutoff.split(":").map((v) => parseInt(v, 10));
  const limit = new Date(now);
  limit.setHours(h || 0, m || 0, 0, 0);
  return now.getTime() > limit.getTime();
}

export function startOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
